<?php
// index file necessary for WP theme to work correctly