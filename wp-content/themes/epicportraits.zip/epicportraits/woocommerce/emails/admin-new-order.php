<?php
/**
 * Admin new order email
 *
 * @author WooThemes
 * @package WooCommerce/Templates/Emails/HTML
 * @version 2.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

$orderURL = get_site_url().'/wp-admin/post.php?post='.str_replace('#', '', $order->get_order_number().'&action=edit');



$sql = "
	SELECT `meta_value`
	FROM `wp_postmeta` 
	WHERE `post_id` = ".$order->id."
	AND `meta_key` = '_order_total'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$orderTotal = '$'.number_format(mysql_result($result, 0, 'meta_value'), 2, '.', '');
}
else {
	$orderTotal = '$0.00';
}



$sql = "
	SELECT `order_item_name`
	FROM `wp_woocommerce_order_items` 
	WHERE `order_id` = ".$order->id."
	AND `order_item_type` = 'line_item'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$itemText = mysql_result($result, 0, 'order_item_name');
}
else {
	$itemText = '';
}

$sql = "
	SELECT `order_item_name`
	FROM `wp_woocommerce_order_items` 
	WHERE `order_id` = ".$order->id."
	AND `order_item_name` LIKE '%Mounting (%'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$mountingText = str_replace('Mounting', '', mysql_result($result, 0, 'order_item_name'));
}
else {
	$mountingText = '';
}


$productText = $itemText.$mountingText;


?>

<?php do_action( 'woocommerce_email_header', $email_heading ); ?>

<?php do_action( 'woocommerce_email_before_order_table', $order, true, false ); ?>


<table cellspacing="0" cellpadding="10" style="width: 100%;" border="0">
	<tbody>
		<tr>
			<td valign="top" colspan='2'>
				<div style='font-size: 34px; font-weight: 700; color: #436178;'>A new order has been recieved!</div>
				<div style='clear: both; font-size: 24px; font-weight: 700; color: #436178; padding-bottom: 15px;'>Order Number <?php echo $order->get_order_number(); ?></div>
			</td>
		</tr>

		<tr style='font-size: 24px; font-weight: 700; color: #436178;'>
			<td>Order</td>
			<td>Price</td>
		</tr>

		<tr>
			<td><a href='<?php echo $orderURL; ?>' target='_blank' style='font-size: 16px; color: #436178; text-decoration: none;'><?php echo $productText; ?></a></td>
			<td style='font-size: 16px; color: #436178;'><?php echo $orderTotal; ?></td>
		</tr>

		<tr>
			<td valign="top" colspan='2' style='text-align: center; padding-top: 40px;'>
				<a href='<?php echo $orderURL; ?>' target='_blank' style='text-decoration: none; font-size: 20px; font-weight: 700; color: #436178; text-align: center;'>Click here to view the full order</a>
			</td>
		</tr>

	</tbody>
</table>

<?php do_action( 'woocommerce_email_after_order_table', $order, true, false ); ?>

<?php do_action( 'woocommerce_email_footer' ); ?>