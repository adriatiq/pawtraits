<?php
/**
 * Customer completed order email
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<?php do_action( 'woocommerce_email_header', $email_heading ); ?>

<?php do_action( 'woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text ); ?>

<table cellspacing="0" cellpadding="10" style="width: 100%;" border="0">
	<tbody>
		<tr>
			<td valign="top">
				<?php
					$sql = "
						SELECT meta_value
						FROM wp_postmeta
						WHERE post_id = ".$order->id."
						AND meta_key = 'completed_image'
					";
					$result = mysql_query($sql);

					if (mysql_num_rows($result)>0) {
						$imageID = mysql_result($result, 0, 'meta_value');

						if ($imageID!='') {
							$sql2 = "
								SELECT `ID`, `guid`
								FROM wp_posts
								WHERE `ID` = ".$imageID."
							";
							$result2 = mysql_query($sql2);

							if (mysql_num_rows($result2)>0) {
								$completedImageID = mysql_result($result2, 0, 'ID');
								$completedImageFullURL = mysql_result($result2, 0, 'guid');

								$imageArray = image_downsize($completedImageID, 'email');
							    $completedImageURL = $imageArray[0];

							    echo "<a href='".$completedImageFullURL."' target='_blank'><img src='".$completedImageURL."' alt='' /></a><br />";

							    // share links
							    $shareUrl = site_url('/share/' . $order->id .'/');
							    echo "<a href='$shareUrl?share=fb'><img src='".get_theme_root_uri()."/epicportraits/images/facebookButton.png' alt='' /></a>";
							    echo "<a href='$shareUrl?share=tw'><img src='".get_theme_root_uri()."/epicportraits/images/twitterButton.png' alt='' /></a>";

							    // original direct sharer urls
								// echo "<a href='https://www.facebook.com/sharer/sharer.php?u=" . urlencode(get_permalink($order->id)) . "' target='_blank'><img src='".get_theme_root_uri()."/epicportraits/images/facebookButton.png' alt='' /></a>";
								// echo "<a href='https://twitter.com/home?status=" . urlencode(get_permalink($order->id)) . "' target='_blank'><img src='".get_theme_root_uri()."/epicportraits/images/twitterButton.png' alt='' /></a>";
							}
						}
					}
				?>
			</td>

			<td valign="top">
				<div style='font-size: 34px; font-weight: 700; color: #436178;'>Congratulations!</div>
				<div style='font-size: 22px; font-weight: 700; color: #436178;'>Your portrait has been shipped.</div>
				<br />

				<?php
					$sql = "
						SELECT meta_value
						FROM wp_postmeta
						WHERE post_id = ".$order->id."
						AND (meta_key = 'tracking_number'
						OR meta_key = 'courier')
						AND meta_value != ''
						ORDER BY meta_key ASC
					";
					$result = mysql_query($sql);

					if (mysql_num_rows($result)==2) {
						$courier = mysql_result($result, 0, 'meta_value');
						$trackingNumber = mysql_result($result, 1, 'meta_value');


						echo "
							<div style='font-size: 16px; font-weight: 700; color: #436178;'>Your shipping tracking number is:</div>
							<div style='font-size: 22px; font-weight: 700; color: #436178;padding: 6px 0;'>".$trackingNumber."</div>

							<div style='font-size: 14px; font-weight: 700; color: #436178;'>You can track your order with the above number via ".$courier.".</div>
							<br />
						";
					}
				?>



				<?php
					$sql = "
						SELECT `order_item_name`
						FROM `wp_woocommerce_order_items`
						WHERE `order_id` = ".$order->id."
						AND `order_item_name` LIKE '%Mounting (%'
					";
					$result = mysql_query($sql);

					if (mysql_num_rows($result)>0) {
						$mountingText = mysql_result($result, 0, 'order_item_name');

						$tmp = explode('(', $mountingText);
						$tmp = explode(' - ', $tmp[1]);

						$mounting = $tmp[0];



						$sql2 = "
							SELECT `ID`
							FROM `wp_posts`
							WHERE `post_title` = '".$mounting." Info'
						";
						$result2 = mysql_query($sql2);

						if (mysql_num_rows($result2)>0) {
							$postID = mysql_result($result2, 0, 'ID');

							$sql3 = "
								SELECT `meta_value`
								FROM `wp_postmeta`
								WHERE `post_id` = ".$postID."
								AND `meta_key` = 'care_tips'
							";
							$result3 = mysql_query($sql3);

							if (mysql_num_rows($result3)>0) {
								$careTips = mysql_result($result3, 0, 'meta_value');

								echo "
									<div style='font-size: 16px; font-weight: 700; color: #436178;'>Here are some tips for caring for and <br />displaying your awesome new portrait.</div>
									<div style='font-size: 12px; color: #436178; padding-top: 10px;'>
										".nl2br($careTips)."
									</div>
								";
							}
						}
					}
				?>

			</td>

		</tr>

		<tr>
			<td colspan='2'><div style='font-size: 14px; font-weight: 700; color: #436178; text-align: center; padding-top: 10px;'>Share your portrait and receive a 10% discount gift voucher to give to your friends!</div></td>
		</tr>
	</tbody>
</table>

<?php do_action( 'woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text ); ?>
<?php do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text ); ?>

<?php do_action( 'woocommerce_email_footer' ); ?>