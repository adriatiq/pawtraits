<?php
/**
 * Customer processing order email
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails/Plain
 * @version     2.2.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



$sql = "
	SELECT `meta_value`
	FROM `wp_postmeta` 
	WHERE `post_id` = ".$order->id."
	AND `meta_key` = '_order_total'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$orderTotal = '$'.number_format(mysql_result($result, 0, 'meta_value'), 2, '.', '');
}
else {
	$orderTotal = '$0.00';
}



$sql = "
	SELECT `order_item_name`
	FROM `wp_woocommerce_order_items` 
	WHERE `order_id` = ".$order->id."
	AND `order_item_type` = 'line_item'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$itemText = mysql_result($result, 0, 'order_item_name');
}
else {
	$itemText = '';
}

$sql = "
	SELECT `order_item_name`
	FROM `wp_woocommerce_order_items` 
	WHERE `order_id` = ".$order->id."
	AND `order_item_name` LIKE '%Mounting (%'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$mountingText = str_replace('Mounting', '', mysql_result($result, 0, 'order_item_name'));
}
else {
	$mountingText = '';
}


$productText = $itemText.$mountingText;


// --------------------------------------------------------------


echo "Thanks for ordering an Epic Portrait!

Your order has been received and is now being processed. Your order details are shown below for your reference:

Order Number ".$order->get_order_number()."

Order -
".$productText." | ".$orderTotal."

Copyright Design Lift".date('Y');