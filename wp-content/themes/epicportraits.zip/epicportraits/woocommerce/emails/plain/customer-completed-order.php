<?php
/**
 * Customer completed order email (plain text)
 *
 * @author		WooThemes
 * @package		WooCommerce/Templates/Emails/Plain
 * @version		2.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


echo "Congratulations! Your order has been shipped.";

$sql = "
	SELECT meta_value
	FROM wp_postmeta
	WHERE post_id = ".$order->id."
	AND (meta_key = 'tracking_number'
	OR meta_key = 'courier')
	AND meta_value != ''
	ORDER BY meta_key ASC
";
$result = mysql_query($sql);

if (mysql_num_rows($result)==2) {
	$courier = mysql_result($result, 0, 'meta_value');
	$trackingNumber = mysql_result($result, 1, 'meta_value');
	

echo "
Your shipping tracking number is: ".$trackingNumber."
You can track your order with the above number via ".$courier;
}




$sql = "
	SELECT `order_item_name`
	FROM `wp_woocommerce_order_items` 
	WHERE `order_id` = ".$order->id."
	AND `order_item_name` LIKE '%Mounting (%'
";
$result = mysql_query($sql);

if (mysql_num_rows($result)>0) {
	$mountingText = mysql_result($result, 0, 'order_item_name');

	$tmp = explode('(', $mountingText);
	$tmp = explode(' - ', $tmp[1]);

	$mounting = $tmp[0];



	$sql2 = "
		SELECT `ID`
		FROM `wp_posts` 
		WHERE `post_title` = '".$mounting." Info'
	";
	$result2 = mysql_query($sql2);

	if (mysql_num_rows($result2)>0) {
		$postID = mysql_result($result2, 0, 'ID');

		$sql3 = "
			SELECT `meta_value`
			FROM `wp_postmeta` 
			WHERE `post_id` = ".$postID."
			AND `meta_key` = 'care_tips'
		";
		$result3 = mysql_query($sql3);

		if (mysql_num_rows($result3)>0) {
			$careTips = mysql_result($result3, 0, 'meta_value');

echo "

Here are some tips for caring for and displaying your awesome new portrait:

".nl2br($careTips);
		}
	}
}


echo "

Copyright Design Lift".date('Y');