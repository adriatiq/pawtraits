<?php
	// Header
	include 'includes/headStyles.php';
?>
		<link rel="stylesheet" href="<?php echo $themePath; ?>css/tips-tricks.css">

		<script type='text/javascript' src='<?php echo $themePath; ?>js/lib/jquery.lazyload.min.js'></script>
		<script type='text/javascript' src='<?php echo $themePath; ?>js/tips-tricks.js'></script>
	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper regularPage'>




			<?php
				include 'includes/topMenu.php';
				include 'includes/pageNav.php';
			?>




			<!---------- CONTENT PANEL ---------->

			<section class='contentPanel' rel='addNavPadding' style='text-align: center;'>

				<h1>404 - Page Not found</h1>

				<span style='font-size: 18px;'>
					Sorry, the page you are looking for has either moved or never existed in the first place.<br />
					<br />
				</span>
				<a href='<?php echo $sitePath; ?>#designs' class='bigButton'>Browse our portrait designs</a>

				<?php include 'includes/copyright.php'; ?>

			</section> <!-- .contentPanel -->



		</div> <!-- .contentWrapper -->





		<?php
			// Footer
			include 'includes/footer.php';
		?>

	</body>
</html>