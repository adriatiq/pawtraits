<?php
	// Header
	include 'includes/headStyles.php';
	global $wpdb;
	echo "
		<link href='http://fonts.googleapis.com/css?family=Covered+By+Your+Grace' rel='stylesheet' type='text/css'>
		<link rel='stylesheet' href='".$themePath."css/portrait.css'>
		<script type='text/javascript' src='".$themePath."js/portrait.js'></script>
		<script type='text/javascript' src='".$themePath."js/lib/jquery.visible.min.js'></script>

		<link href='".$themePath."css/dropzone.css' rel='stylesheet' type='text/css'>
		<script type='text/javascript' src='".$themePath."js/lib/dropzone.js'></script>
	";


	// Get portrait ID
	$tmp = explode('/', $_SERVER['REQUEST_URI']);
	array_pop($tmp);
	$id = end($tmp);

	// Ensure it's a valid portrait ID
	$sql = "
		SELECT `ID`, `post_title`, `post_content`
		FROM  `wp_posts`
		WHERE `post_type` =  'product'
		AND `post_status` = 'publish'
		AND `post_name` = '".$id."'
	";
	$result = $wpdb->get_row($sql);

	if (count($result)==0) {
		echo "
			<script type='text/javascript'>
				window.location = '".get_site_url()."?error=portraitDoesNotExist';
			</script>
		";
	}
	// If it's valid, get the data out
	else {
		$id = $result->ID;
		$title = $result->post_title;
		$content = apply_filters('the_content', $result->post_content);


		// Get the price
		$product = new WC_Product($id);
		if ($product->price) {
			$price = number_format($product->price, 2);
		}
		else {
			$price = 0;
		}




		$cat_arr = wp_get_post_terms($id, 'product_cat');
		$categories = array();
		for ($z=0; $z<count($cat_arr); $z++) {
			array_push($categories, $cat_arr[$z]->term_id);
		}

		echo "
			<script type='text/javascript'>
				var product_id = ".$id.";
				var product_cats = [];
		";

		for ($i=0; $i<count($categories); $i++) {
			echo "product_cats[".$i."] = '".$categories[$i]."';";
		}

		echo "</script>";

		if ($product->is_on_sale()) {
			echo "
				<script type='text/javascript'>
					var on_sale = true;
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					var on_sale = false;
				</script>
			";
		}


/*
// NOT USED ANYMORE
// instead coupons validated by ajax for enhanced security


		// Get all valid coupons and output to JS array
		// USE THIS TO INCREASE THE USAGE COUNT OF A COUPON:
		// $coupon = new WC_Coupon($coupon_code);
		// $coupon->inc_usage_count('test@test.com');

		$sql2 = "
			SELECT a.post_title, b.meta_key, b.meta_value
			FROM wp_posts a, wp_postmeta b
			WHERE a.post_type = 'shop_coupon'
			AND a.id = b.post_id
			AND (b.meta_key = 'free_shipping'
				OR b.meta_key = 'discount_type'
				OR b.meta_key = 'coupon_amount'
				OR b.meta_key = 'expiry_date'
				OR b.meta_key = 'usage_count'
				OR b.meta_key = 'usage_limit'
				OR b.meta_key = 'exclude_sale_items'
				OR b.meta_key = 'product_categories'
				OR b.meta_key = 'exclude_product_categories'
				OR b.meta_key = 'product_ids'
				OR b.meta_key = 'exclude_product_ids'
			)
			ORDER BY a.post_title, b.meta_key DESC
		";
		$result2 = $wpdb->get_results($sql2);

		echo "
			<script type='text/javascript'>
				var couponCodes = [];
		";

		$prev_code = '';
		foreach ($result2 as $prod ) {
			$coupon_code = $prod->post_title;
			$meta_key = $prod->meta_key;
			$meta_value = $prod->meta_value;

			$meta_value = str_replace('_cart', '', $meta_value);

			if ($meta_key=='expiry_date') {
				$meta_value = str_replace('-', '', $meta_value);
			}

			$coupon = new WC_Coupon($coupon_code);
			if ($prev_code!=$coupon_code) {
				echo "couponCodes['".$coupon_code."'] = [];";
			}
			echo "couponCodes['".$coupon_code."']['".$meta_key."'] = '".$meta_value."';";

			$prev_code = $coupon_code;
		}
		echo "</script>";

*/


		// Get the instructions image
		if (class_exists('MultiPostThumbnails')) { $instructions_image_url = MultiPostThumbnails::get_post_thumbnail_url('product', 'instructions-image', $id); }

		// Get the custom field data
		$data = get_post_meta($id);

		if (isset($data['template_color'][0])) { $template_color = strtolower($data['template_color'][0]); } else { $template_color = 'pink'; }
		if (isset($data['maximum_figures'][0])) { $max_figures = $data['maximum_figures'][0]; } else { $max_figures = 0; }
		if (isset($data['minimum_figures'][0])) { $min_figures = $data['minimum_figures'][0]; } else { $min_figures = 1; }
		if (isset($data['photo_requirements'][0])) { $requirements = $data['photo_requirements'][0]; } else { $requirements = ''; }
		if (isset($data['includes'][0])) { $includes = $data['includes'][0]; } else { $includes = ''; }
		if (isset($data['photo_instructions'][0])) { $instructions = $data['photo_instructions'][0]; } else { $instructions = ''; }
		if (isset($data['general_fields'][0])) { $general_fields = $data['general_fields'][0]; } else { $general_fields = ''; }
		if (isset($data['figure_fields'][0])) { $figure_fields = $data['figure_fields'][0]; } else { $figure_fields = ''; }
		if (isset($data['price_per_figure'][0]) && $data['price_per_figure'][0]!='') { $price_per_figure = $data['price_per_figure'][0]; } else { $price_per_figure = 0; }



		// Output the price variables
		echo "
			<script type='text/javascript'>
				var price_per_figure = ".$price_per_figure.";
				var price = ".$price.";
			</script>
		";



		// Turn includes into a list
		if ($includes!='') {
			$bits = explode("\n", $includes);

			$newstring = "<ul>";
			foreach($bits as $bit) {
				$newstring .= "<li>".$bit."</li>";
			}
			$newstring .= "</ul>";

			$includes = $newstring;
		}




		// Setup figures text
		if ($min_figures==$max_figures) {
			if ($min_figures==1) {
				$figures_text = $min_figures.' Person Only';
			}
			else {
				$figures_text = $min_figures.' People Only';
			}
		}
		else if ($min_figures!=0 && $max_figures==0) {
			if ($min_figures==1) {
				$figures_text = 'Minimum '.$min_figures.' Person';
			}
			else {
				$figures_text = 'Minimum '.$min_figures.' People';
			}
		}
		else if ($max_figures!=0 && $min_figures!=0) {
			$figures_text = $min_figures.' to '.$max_figures.' People';
		}

		// Get the regular image (large thumb / fullsize)
		$thumb = get_the_post_thumbnail($id, 'large');
		if ($thumb!==false) {
			$thumb_url = (preg_match('~\bsrc="([^"]++)"~', $thumb, $matches)) ? $matches[1] : '';
		}

		$image = get_the_post_thumbnail($id);
		if ($image!==false) {
			$image_url = (preg_match('~\bsrc="([^"]++)"~', $image, $matches)) ? $matches[1] : '';
		}







		// Get out the mounting options AND allowed countries AND shipping costs
		$sql = "
			SELECT `option_value`
			FROM wp_options
			WHERE `option_name` = 'wc_settings_tab_mounting_paper'
			OR `option_name` = 'wc_settings_tab_mounting_canvas'
			OR `option_name` = 'wc_settings_tab_mounting_acrylic'
			OR `option_name` = 'woocommerce_specific_allowed_countries'
			OR `option_name` = 'wc_settings_tab_shipping_local'
			OR `option_name` = 'wc_settings_tab_shipping_international'
			ORDER BY `option_name` DESC
		";
		$result = $wpdb->get_results($sql,ARRAY_A);

		$allowed_countries = $result[0]['option_value'];
		$local_delivery = $result[1]['option_value'];
		$international_delivery = $result[2]['option_value'];
		$paper = $result[3]['option_value'];
		$canvas = $result[4]['option_value'];
		$acrylic = $result[5]['option_value'];

		echo "
			<script type='text/javascript'>
				var local_delivery = '".$local_delivery."';
				var international_delivery = '".$international_delivery."';
			</script>
		";


		// Allowed Countries Stuff
		$tmp = explode('"', $allowed_countries);
		foreach($tmp as $key => $value) {
			if(!($key&1)) {
				unset($tmp[$key]);
			}
		}

		// Get array of all countries (country code as key)
		include 'wp-content/plugins/woocommerce/i18n/countries.php';

		$allowed_countries = array();
		foreach($tmp as $key => $value) {
			array_push($allowed_countries, $value);

			// Also get the states for this country
			if (file_exists('wp-content/plugins/woocommerce/i18n/states/'.$value.'.php')) {
				include 'wp-content/plugins/woocommerce/i18n/states/'.$value.'.php';
			}
		}

		// Output the states to a JS array
		echo "
			<script type='text/javascript'>
				var states = [];
		";

		foreach($states as $key => $value) {
			echo "states['".$key."'] = [];";

			foreach($states[$key] as $key2 => $value2) {
				echo "states['".$key."']['".$key2."'] = '".addslashes($value2)."';";
			}
		}

		echo "</script>";


		$arr = preg_split("/\\r\\n|\\r|\\n/", str_replace(' ', '', strtolower(trim($paper))));
		$paper = array();
		for ($i=0; $i<count($arr); $i++) {
			$paper[$i] = array();

			$tmp = explode('x', $arr[$i]);
			$tmp2 = explode('|', $tmp[1]);

			$paper[$i]['width'] = $tmp[0];
			$paper[$i]['height'] = $tmp2[0];
			$paper[$i]['price'] = $tmp2[1];
			$paper[$i]['postage'] = $tmp2[2];
		}


		$arr = preg_split("/\\r\\n|\\r|\\n/", str_replace(' ', '', strtolower(trim($canvas))));
		$canvas = array();
		for ($i=0; $i<count($arr); $i++) {
			$canvas[$i] = array();

			$tmp = explode('x', $arr[$i]);
			$tmp2 = explode('|', $tmp[1]);

			$canvas[$i]['width'] = $tmp[0];
			$canvas[$i]['height'] = $tmp2[0];
			$canvas[$i]['price'] = $tmp2[1];
			$canvas[$i]['postage'] = $tmp2[2];
		}


		$arr = preg_split("/\\r\\n|\\r|\\n/", str_replace(' ', '', strtolower(trim($acrylic))));
		$acrylic = array();
		for ($i=0; $i<count($arr); $i++) {
			$acrylic[$i] = array();

			$tmp = explode('x', $arr[$i]);
			$tmp2 = explode('|', $tmp[1]);

			$acrylic[$i]['width'] = $tmp[0];
			$acrylic[$i]['height'] = $tmp2[0];
			$acrylic[$i]['price'] = $tmp2[1];
			$acrylic[$i]['postage'] = $tmp2[2];
		}


		// Workout which mounting options are enabled
		$enabledPaper = array();
		$z = 0;
		for ($i=0; $i<count($paper); $i++) {
			$tmpID = 'paper_'.$paper[$i]['width'].'x'.$paper[$i]['height'];

			if (isset($data[$tmpID][0]) && $data[$tmpID][0]=='yes') {
				$enabledPaper[$z] = array();
				$enabledPaper[$z]['width'] = $paper[$i]['width'];
				$enabledPaper[$z]['height'] = $paper[$i]['height'];
				$enabledPaper[$z]['price'] = $paper[$i]['price'];
				$enabledPaper[$z]['postage'] = $paper[$i]['postage'];
				$z++;
			}
		}


		$enabledCanvas = array();
		$z = 0;
		for ($i=0; $i<count($canvas); $i++) {
			$tmpID = 'canvas_'.$canvas[$i]['width'].'x'.$canvas[$i]['height'];

			if (isset($data[$tmpID][0]) && $data[$tmpID][0]=='yes') {
				$enabledCanvas[$z] = array();
				$enabledCanvas[$z]['width'] = $canvas[$i]['width'];
				$enabledCanvas[$z]['height'] = $canvas[$i]['height'];
				$enabledCanvas[$z]['price'] = $canvas[$i]['price'];
				$enabledCanvas[$z]['postage'] = $canvas[$i]['postage'];
				$z++;
			}
		}


		$enabledAcrylic = array();
		$z = 0;
		for ($i=0; $i<count($acrylic); $i++) {
			$tmpID = 'acrylic_'.$acrylic[$i]['width'].'x'.$acrylic[$i]['height'];

			if (isset($data[$tmpID][0]) && $data[$tmpID][0]=='yes') {
				$enabledAcrylic[$z] = array();
				$enabledAcrylic[$z]['width'] = $acrylic[$i]['width'];
				$enabledAcrylic[$z]['height'] = $acrylic[$i]['height'];
				$enabledAcrylic[$z]['price'] = $acrylic[$i]['price'];
				$enabledAcrylic[$z]['postage'] = $acrylic[$i]['postage'];
				$z++;
			}
		}





		// Format the fields stuff
		if ($general_fields!='') {
			$arr = preg_split("/\\r\\n|\\r|\\n/", trim($general_fields));
			$general_fields = array();
			for ($i=0; $i<count($arr); $i++) {
				$general_fields[$i] = array();

				$tmp = explode('|', $arr[$i]);
				$general_fields[$i]['type'] = $tmp[0];
				$general_fields[$i]['name'] = $tmp[1];
				$general_fields[$i]['required'] = $tmp[2];
			}
		}
		else {
			$general_fields = array();
		}

		if ($figure_fields!='') {
			$arr = preg_split("/\\r\\n|\\r|\\n/", trim($figure_fields));
			$figure_fields = array();
			for ($i=0; $i<count($arr); $i++) {
				$figure_fields[$i] = array();

				$tmp = explode('|', $arr[$i]);
				$figure_fields[$i]['type'] = $tmp[0];
				$figure_fields[$i]['name'] = $tmp[1];
				$figure_fields[$i]['required'] = $tmp[2];
			}
		}
		else {
			$figure_fields = array();
		}
?>

	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper'>




			<?php
				echo "<script type='text/javascript'>var navColor = '".$template_color."';</script>";
				include 'includes/nav.php';
			?>




			<!---------- PORTRAIT PANEL ---------->

			<section class='portraitPanel <?php echo $template_color; ?> currentPanel' rel='addNavPadding'>
				<div class='innerPanel' rel='addNavNegativeMargin'>
					<div class='portraitDetails'>

						<?php
							if ($thumb_url!='') {
								echo "
									<div class='portraitPreview'>
										<a href=\"javascript: showModal('<img src=\'".$image_url."\' alt=\'\' />', 'regular');\"><img src='".$thumb_url."' alt='' /></a>
										<span class='enlarge-hint'>Click To Enlarge</span>
									</div> <!-- .portraitPreview -->
								";
							}
						?>

						<div class='subTitle'>Portrait Design:</div>
						<h1 class='title'><?php echo $title; ?></h1>
						<div class='text'><?php echo $content; ?></div>
						<ul class='requirements'>
							<li>Figures: <strong><?php echo $figures_text; ?></strong></li>
							<?php
								if ($requirements!='') {
									echo "<li>Photo requirements: <strong>".$requirements."</strong></li>";
								}
								if ($includes!='') {
									echo "<li><div style='float: left;'>Includes:&#160;</div> <div style='float: left; font-weight: bold;'>".$includes."</div></li>";
								}
							?>
						</div> <!-- .requirements -->
					</ul> <!-- .portraitDetails -->

					<div class='photoInstructions'>
						<div class='title'>Photo Instructions</div>
						<div class='text'>
							<?php echo nl2br($instructions); ?>
							<div class='clear'></div>
							<a href='photography-tips-tricks'>View all general tips &amp; tricks</a>
						</div>
						<?php
						if ($instructions_image_url!='') {
							echo "<img src='".$instructions_image_url."' alt='' />";
						}
						?>
					</div> <!-- .photoInstructions -->
					<div class='clear'></div>
				</div> <!-- .innerPanel -->

				<div class='nextButton'>
					<a href="javascript: enablePanel('mountingPanel'); changePanel('mountingPanel');">Next Step: <strong>Choose Mounting</strong></a>
				</div> <!-- .nextButton -->

			</section> <!-- .portraitPanel -->




			<!---------- MOUNTING PANEL ---------->

			<section class='mountingPanel' rel='addNavPadding'>
				<div class='innerPanel' rel='addNavNegativeMargin'>


					<div class="mounting-select-mobile">
						<div class='filterDropdown' rel='mandatory'>
							<select onchange="mobileMountSelect();">
								<option value='all' disabled="disabled" selected="selected">Choose Mounting</option>

								<?php // Generate options for paper
								if (count($enabledPaper)>0) {
									echo '<option value="" disabled="disabled">-- Heavyweight 260gm Satin Art Paper --</option>';
									for ($i=0; $i<count($enabledPaper); $i++) {
										echo "<option data-type='paper' data-dimensions='".$enabledPaper[$i]['width']."mm x ".$enabledPaper[$i]['height']."mm' data-price='".$enabledPaper[$i]['price']."' data-postage='".$enabledPaper[$i]['postage']."'>Paper ".$enabledPaper[$i]['width']."mm x ".$enabledPaper[$i]['height']."mm</div>";
									}
								} ?>
								<?php // Generate options for paper
								if (count($enabledCanvas)>0) {
									echo '<option value="" disabled="disabled">-- Gallery wrap style --</option>';
									for ($i=0; $i<count($enabledCanvas); $i++) {
										echo "<option data-type='canvas' data-dimensions='".$enabledCanvas[$i]['width']."mm x ".$enabledCanvas[$i]['height']."mm' data-price='".$enabledCanvas[$i]['price']."' data-postage='".$enabledCanvas[$i]['postage']."'>Canvas ".$enabledCanvas[$i]['width']."mm x ".$enabledCanvas[$i]['height']."mm</div>";
									}
								} ?>
								<?php // Generate options for paper
								if (count($enabledAcrylic)>0) {
									echo '<option value="" disabled="disabled">-- 4mm Acrylic with Stainless steel wall mounts --</option>';
									for ($i=0; $i<count($enabledAcrylic); $i++) {
										echo "<option data-type='acrylic' data-dimensions='".$enabledAcrylic[$i]['width']."mm x ".$enabledAcrylic[$i]['height']."mm' data-price='".$enabledAcrylic[$i]['price']."' data-postage='".$enabledAcrylic[$i]['postage']."'>Acrylic ".$enabledAcrylic[$i]['width']."mm x ".$enabledAcrylic[$i]['height']."mm</div>";
									}
								} ?>
							</select>
						</div>

						<div class="info"></div>
					</div>

					<script>
						function mobileMountSelect() {
							var $option = $('.mounting-select-mobile option:selected');
							selectOption($option.data('type') + 'Select', $option.data('dimensions'), $option.data('price'), $option.data('postage') );

							// show info from desktop version html
							var $wrap = $('.mounting-select-desktop > .' + $option.data('type'));
							$('.mounting-select-mobile .info').html($('h2.title', $wrap).clone());
							$('.mounting-select-mobile .info').append($('div.for_mob .description', $wrap).clone());
						}
					</script>


					<div class="mounting-select-desktop">

						<?php if (count($enabledPaper)>0) { ?>
						<div class='paper'>
							<img src='<?php echo $themePath; ?>images/paperIcon.png' alt='' />
							<h2 class='title for_desk'>Paper</h2>
							<div class='description for_desk'>
								Heavyweight 260gm Satin Art Paper<br />

								<?php
									$sql = "
										SELECT `post_content`
										FROM wp_posts
										WHERE `ID` = 484
									";
									$result = $wpdb->get_row($sql);

									$paperText = '';

									if ($wpdb->num_rows>0) {
										$paperText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

										echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Paper Information</h2>".addslashes(str_replace('"', "'", $paperText))."</div>', 'text');\">Learn more</a>";
									}
								?>

							</div> <!-- .description -->

							<div class='selectBoxContainer'>
								<div class='selectBox' tabindex="-1" id='paperSelect' ontouchend="$(this).focus();">
									<div class='selectedOption'>Choose Paper Mounting</div>
									<?php
										for ($i=0; $i<count($enabledPaper); $i++) {
											$dimensions = $enabledPaper[$i]['width']."mm x ".$enabledPaper[$i]['height']."mm";
											echo "<div class='option' data-type='paper' data-dimensions='$dimensions' rel='".$enabledPaper[$i]['price']."' name='".$enabledPaper[$i]['postage']."'>$dimensions</div>";
										}
									?>
								</div> <!-- .selectBox -->
							</div> <!-- .selectBoxContainer -->
							<div class="for_mob">
								<h2 class='title'>Paper</h2>
							<div class='description'>
								Heavyweight 260gm Satin Art Paper<br />

								<?php
									$sql = "
										SELECT `post_content`
										FROM wp_posts
										WHERE `ID` = 484
									";
									$result = $wpdb->get_row($sql);

									$paperText = '';

									if ($wpdb->num_rows>0) {
										$paperText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

										echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Paper Information</h2>".addslashes(str_replace('"', "'", $paperText))."</div>', 'text');\">Learn more</a>";
									}
								?>

							</div> <!-- .description -->
							</div>
						</div> <!-- .paper -->
						<?php } ?>



						<?php if (count($enabledCanvas)>0) { ?>
						<div class='canvas'>
							<img src='<?php echo $themePath; ?>images/canvasIcon.png' alt='' />
							<h2 class='title for_desk'>Canvas</h2>
							<div class='description for_desk'>
								Gallery wrap style<br />


								<?php
									$sql = "
										SELECT `post_content`
										FROM wp_posts
										WHERE `ID` = 488
									";
									$result = $wpdb->get_row($sql);

									$canvasText = '';
									if ($wpdb->num_rows>0) {
										$canvasText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

										echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Canvas Information</h2>".addslashes(str_replace('"', "'", $canvasText))."</div>', 'text');\">Learn more</a>";
									}
								?>


							</div> <!-- .description -->

							<div class='selectBoxContainer'>
								<div class='selectBox' tabindex="-1" id='canvasSelect' ontouchend="$(this).focus();">
									<div class='selectedOption'>Choose Canvas Mounting</div>
									<?php
										for ($i=0; $i<count($enabledCanvas); $i++) {
											$dimensions = $enabledCanvas[$i]['width']."mm x ".$enabledCanvas[$i]['height']."mm";
											echo "<div class='option' data-type='canvas' data-dimensions='$dimensions' rel='".$enabledCanvas[$i]['price']."' name='".$enabledCanvas[$i]['postage']."'>$dimensions</div>";
										}
									?>
								</div> <!-- .selectBox -->
							</div> <!-- .selectBoxContainer -->
							<div class="for_mob">
								<h2 class='title'>Canvas</h2>
								<div class='description'>
									Gallery wrap style<br />


									<?php
										$sql = "
											SELECT `post_content`
											FROM wp_posts
											WHERE `ID` = 488
										";
										$result = $wpdb->get_row($sql);

										$canvasText = '';
										if ($wpdb->num_rows>0) {
											$canvasText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

											echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Canvas Information</h2>".addslashes(str_replace('"', "'", $canvasText))."</div>', 'text');\">Learn more</a>";
										}
									?>


								</div> <!-- .description -->
							</div>
						</div> <!-- .canvas -->
						<?php } ?>



						<?php if (count($enabledAcrylic)>0) { ?>
						<div class='acrylic'>
							<img src='<?php echo $themePath; ?>images/acrylicIcon.png' alt='' />
							<h2 class='title for_desk'>Acrylic</h2>
							<div class='description for_desk'>
								4mm Acrylic with Stainless steel wall mounts<br />


								<?php
									$sql = "
										SELECT `post_content`
										FROM wp_posts
										WHERE `ID` = 490
									";
									$result = $wpdb->get_row($sql);

									$acrylicText = '';
									if ($wpdb->num_rows>0) {
										$acrylicText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

										echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Acrylic Information</h2>".addslashes(str_replace('"', "'", $acrylicText))."</div>', 'text');\">Learn more</a>";
									}
								?>


							</div> <!-- .description -->

							<div class='selectBoxContainer'>
								<div class='selectBox' tabindex="-1" id='acrylicSelect' ontouchend="$(this).focus();">
									<div class='selectedOption'>Choose Acrylic Mounting</div>
									<?php
										for ($i=0; $i<count($enabledAcrylic); $i++) {
											$dimensions = $enabledAcrylic[$i]['width']."mm x ".$enabledAcrylic[$i]['height']."mm";
											echo "<div class='option' data-type='acrylic' data-dimensions='$dimensions' rel='".$enabledAcrylic[$i]['price']."' name='".$enabledAcrylic[$i]['postage']."'>".$dimensions."</div>";
										}
									?>
								</div> <!-- .selectBox -->
							</div> <!-- .selectBoxContainer -->
							<div class="for_mob">
								<h2 class='title'>Acrylic</h2>
								<div class='description'>
									4mm Acrylic with Stainless steel wall mounts<br />


									<?php
										$sql = "
											SELECT `post_content`
											FROM wp_posts
											WHERE `ID` = 490
										";
										$result = $wpdb->get_row($sql);

										$acrylicText = '';
										if ($wpdb->num_rows>0) {
											$acrylicText = str_replace('&nbsp;', '<br /><br />', $result->post_content);

											echo "<a href=\"javascript: showModal('<div class=\\'textModalInner termsAndConditionsModal\\'><h2 class=\\'title\\'>Acrylic Information</h2>".addslashes(str_replace('"', "'", $acrylicText))."</div>', 'text');\">Learn more</a>";
										}
									?>


								</div> <!-- .description -->
							</div>
						</div> <!-- .acrylic -->
						<?php } ?>

					</div>


					<div class='preview'>

						<!--
						<div class='summary'>

							<div class='col1'>
								<div class='summaryTitle'>It came from planet earth</div>
								<div class='summaryText'>Canvas mounting<br />(750mm x 1000mm)</div>
							</div>

							<div class='col2'>
								<div class='price'>$337.25</div>
							</div>

						</div>
						-->

						<div class='box'></div>
						<img src='<?php echo $themePath; ?>images/previewIcon.png' alt='' />
					</div> <!-- .preview -->

					<div class='clear'></div>
				</div> <!-- .innerPanel -->

				<div class='errorMessage'><span>Hey, you've missed a few fields. Just finish those off and we're good to go. <img src='<?php echo $themePath; ?>images/errorArrow.png' alt='' /></span></div>

				<div class='nextButton'>
					<a href="javascript: enablePanel('uploadPanel'); changePanel('uploadPanel');">Next Step: <strong>Upload <span class="expendable">your</span> Photos</strong></a>
				</div> <!-- .nextButton -->

			</section> <!-- .mountingPanel -->




			<!---------- UPLOAD PANEL ---------->

			<section class='uploadPanel' rel='addNavPadding'>
				<div class='innerPanel' rel='addNavNegativeMargin'>

					<?php
						if (count($general_fields)>0) {
							echo "
								<h3 class='title'>Custom portrait text</h3>
								<div class='generalForm'>
							";

							for ($i=0; $i<count($general_fields); $i++) {
								if ($general_fields[$i]['type']=='text') {
									if ($general_fields[$i]['required']=='req') {
										$rel = 'mandatory';
									}
									else {
										$rel = '';
									}
									echo "<div style='position: relative;'><input type='text' placeholder='".$general_fields[$i]['name']."' value='' rel='".$rel."' name='general_".$i."' required /><label for='general_".$i."' class='formLabel'>".$general_fields[$i]['name']."</label></div>";
								}
								else if ($general_fields[$i]['type']=='textbox') {
									if ($general_fields[$i]['required']=='req') {
										$rel = 'mandatory';
									}
									else {
										$rel = '';
									}

									echo "<div style='position: relative;'><textarea placeholder='".$general_fields[$i]['name']."' rel='".$rel."' name='general_".$i."' required></textarea><label for='general_".$i."' class='formLabel'>".$general_fields[$i]['name']."</label></div>";
								}
							}

							echo "</div> <!-- .uploadForm -->";
						}
					?>


					<?php
						$figureFormHTML = '';
						if (count($figure_fields)>0) {
							for ($i=0; $i<count($figure_fields); $i++) {
								if ($figure_fields[$i]['type']=='text') {
									if ($figure_fields[$i]['required']=='req') {
										$rel = 'mandatory';
									}
									else {
										$rel = '';
									}
									$figureFormHTML .= "<div style='position: relative;'><input type='text' placeholder='".$figure_fields[$i]['name']."' value='' rel='".$rel."' name='field_".$i."' required /><label for='field_".$i."' class='formLabel'>".$figure_fields[$i]['name']."</label></div>";
								}
								else if ($figure_fields[$i]['type']=='textbox') {
									if ($figure_fields[$i]['required']=='req') {
										$rel = 'mandatory';
									}
									else {
										$rel = '';
									}
									$figureFormHTML .= "<div style='position: relative;'><textarea placeholder='".$figure_fields[$i]['name']."' rel='".$rel."' name='field_".$i."' required></textarea><label for='field_".$i."' class='formLabel'>".$figure_fields[$i]['name']."</label></div>";
								}
							}
						}

						echo "
							<script type='text/javascript'>
								var figureFormHTML = \"".$figureFormHTML."\";
							</script>
						";
					?>


					<h2 class='title'>The '<?php echo $title; ?>' portrait requires <?php echo strtolower($figures_text); ?>. Add them below.</h2>
					<div class='subTitle'><strong>IMPORTANT:</strong> If there is more than one person in a single image, they must be labelled from left to right.</div>


					<script type='text/javascript'>
						var maxForms = <?php echo $max_figures; ?>;
						var minForms = <?php echo $min_figures; ?>;
					</script>

					<div class='uploadFormContainer'></div>

					<a href='javascript: addUploadForm();' class='addNew'><img src='<?php echo $themePath; ?>images/plusIcon.png' alt='' /><span>Add new image</span></a>

					<div class='clear'></div>

					<div class='photoInstructions'>
						Please confirm the images you have uploaded:

						<div class="row">
							<input type='checkbox' autocomplete="off" name='photoInstructions1' value='true' id='photoInstructions1' rel='mandatory' />
							<div class="checkbox">
								<label for="photoInstructions1" id='photoInstructionsLabel1'></label>
							</div>
							<div class="label">
								<span class='checkboxText'>Are of a minimum resolution of 2000px x 2000px Not sure? <a href="/photography-tips-tricks/" target="blank">Find out here</a> (link opens in new page).</span>
							</div>
						</div>

						<div class="row">
							<input type='checkbox' autocomplete="off" name='photoInstructions2' value='true' id='photoInstructions2' rel='mandatory' />
							<div class="checkbox">
								<label for="photoInstructions2" id='photoInstructionsLabel2'></label>
							</div>
							<div class="label">
								<span class='checkboxText'>Do not contain blurred or obstructed figures including standing in grass that obscures feet.</span>
							</div>
						</div>

						<div class="row">
							<input type='checkbox' autocomplete="off" name='photoInstructions3' value='true' id='photoInstructions3' rel='mandatory' />
							<div class="checkbox">
								<label for="photoInstructions3" id='photoInstructionsLabel3'></label>
							</div>
							<div class="label">
								<span class='checkboxText'>Are not wearing clothing with writing or logos as figures may be flipped if facing the wrong way.</span>
							</div>
						</div>

						<div class="row">
							<input type='checkbox' autocomplete="off" name='photoInstructions4' value='true' id='photoInstructions4' rel='mandatory' />
							<div class="checkbox">
								<label for="photoInstructions4" id='photoInstructionsLabel4'></label>
							</div>
							<div class="label">
								<?php
									$instructions = preg_replace('/\s+/', ' ', nl2br(addslashes(html_entity_decode($instructions, ENT_QUOTES, 'UTF-8'))));
								?>
								<span class='checkboxText'>The images uploaded follow our <a href="javascript: showModal('<div class=\'textModalInner photoInstructionsModal\'><h2 class=\'title\'>Photo Instructions</h2><div class=\'text\'><?php echo $instructions; ?></div> <?php if ($instructions_image_url!='') { echo "<img src=\\'".$instructions_image_url."\\' alt=\\'\\' />"; } ?></div>', 'photoInstructions');">Photo Instructions</a></span>
							</div>
						</div>

						<div class="row">
							<input type='checkbox' autocomplete="off" name='newsletterSignup' value='true' id='newsletterSignup' />
							<div class="checkbox">
								<label for="newsletterSignup" id='newsletterSignupLabel'></label>
							</div>
							<div class="label">
								<span class='checkboxText'>Tick this box if you would like to receive information and special offers from time to time. We will never share your information to anyone else.</span>
							</div>
						</div>
					</div> <!-- .photoInstructions -->

					<div class='spacer'></div>

					<div class='clear'></div>
				</div> <!-- .innerPanel -->

				<div class='errorMessage'><span>Hey, you've missed a few fields. Just finish those off and we're good to go. <img src='<?php echo $themePath; ?>images/errorArrow.png' alt='' /></span></div>

				<div class='nextButton'>
					<a href="javascript: enablePanel('detailsPanel'); changePanel('detailsPanel');">Next Step: <strong>Your order details</strong></strong></a>
				</div> <!-- .nextButton -->

			</section> <!-- .uploadPanel -->




			<!---------- DETAILS PANEL ---------->

			<section class='detailsPanel' rel='addNavPadding'>
				<div class='innerPanel' rel='addNavNegativeMargin'>

					<div class='detailsFormContainer'>
						<div class='paymentDetailsForm' id='form1'>
							<h2 class='title'>Your Payment &amp; Account Details</h2>
							<div class='subTitle'>A small amount of information will go here for some reason.</div>

							<div style='position: relative;'>
								<div class='selectContainer' rel='mandatory'>
									<select onchange="$(this).css('color', '#436178'); showStates('country1'); $('#country1_label').addClass('visible');" name='country1' id='country1'>
										<option value='' default selected disabled>Country</option>
										<?php
											for ($i=0; $i<count($allowed_countries); $i++) {
												echo '<option value=\''.$allowed_countries[$i].'\'>'.$countries[$allowed_countries[$i]].'</option>';
											}
										?>
									</select>
									<label for='firstName' class='formLabel' id='country1_label'>Country</label>
								</div> <!-- .selectContainer -->
							</div>

							<div style='position: relative;' class='halfWidth firstHalf'><input type='text' placeholder='First Name' value='' name='firstName' rel='mandatory' required /><label for='firstName' class='formLabel'>First Name</label></div>
							<div style='position: relative;' class='halfWidth'><input type='text' placeholder='Last Name' value='' name='lastName' rel='mandatory' required /><label for='lastName' class='formLabel'>Last Name</label></div>
							<div style='position: relative;'><input type='text' placeholder='Company Name' value='' name='companyName' required /><label for='companyName' class='formLabel'>Company Name</label></div>

							<div style='position: relative;'><input type='text' placeholder='Address' value='' name='address' rel='mandatory' required /><label for='address' class='formLabel'>Address</label></div>
							<div style='position: relative;'><input type='text' placeholder='Address Line 2' value='' name='address2' required /><label for='address2' class='formLabel'>Address Line 2</label></div>
							<div style='position: relative;'><input type='text' placeholder='Town / City' value='' name='city' rel='mandatory' required /><label for='city' class='formLabel'>Town / City</label></div>

							<div style='position: relative;' class='halfWidth firstHalf' id='stateInput1'><input type='text' placeholder='State / County' value='' name='stateInput1' rel='mandatory' required /><label for='stateInput1' class='formLabel'>State / County</label></div>

							<div style='position: relative; display: none;' class='halfWidth firstHalf' id='stateSelect1'>
								<div class='selectContainer' rel='mandatory'>
									<select name='stateSelect1' onchange="$(this).css('color', '#436178'); $('#stateSelect1_label').addClass('visible');" required>
										<option value='' default selected>State / County</option>
									</select>
								</div> <!-- .selectContainer -->
								<label for='stateSelect1' class='formLabel' id='stateSelect1_label'>State / County</label>
							</div>

							<div style='position: relative;' class='halfWidth'><input type='text' placeholder='Postcode / Zip' value='' name='postcode' rel='mandatory' required /><label for='postcode' class='formLabel'>Postcode / Zip</label></div>

							<div style='position: relative;' class='halfWidth firstHalf'><input type='text' placeholder='Email' value='' name='email' rel='mandatory' required /><label for='email' class='formLabel'>Email</label></div>
							<div style='position: relative;' class='halfWidth'><input type='text' placeholder='Phone' value='' name='phone' rel='mandatory' required /><label for='phone' class='formLabel'>Phone</label></div>
						</div> <!-- .paymentDetailsForm -->


						<div class='paymentDetailsForm right' id='form2'>
							<h2 class='title'>Your Shipping Details</h2>
							<div class='subTitle'>A small amount of information will go here for some reason.</div>

							<div class='shipToDifferentAddress' onclick="calculatePostage();">
								<input type='checkbox' autocomplete="off" name='shipToDifferentAddress' value='true' id='shipToDifferentAddress' onchange="if (this.checked) { $('.differentAddress').addClass('visible'); } else {  $('.differentAddress').removeClass('visible'); }" />
								<div class="checkbox">
									<label for="shipToDifferentAddress"></label>
								</div>
								<div class="label">
									<span class='checkboxText'>Ship to a different address?</span>
								</div>
							</div> <!-- .sipToDifferentAddress -->

							<div class='differentAddress'>
								<div style='position: relative;'>
									<div class='selectContainer' rel='mandatory'>
										<select onchange="$(this).css('color', '#436178'); showStates('country2'); $('#country2_label').addClass('visible');" name='country2' id='country2'>
											<option value='' default selected disabled>Country</option>
											<?php
												for ($i=0; $i<count($allowed_countries); $i++) {
													echo '<option value=\''.$allowed_countries[$i].'\'>'.$countries[$allowed_countries[$i]].'</option>';
												}
											?>
										</select>
									</div> <!-- .selectContainer -->
									<label for='country2' id='country2_label' class='formLabel'>Country</label>
								</div>

								<div style='position: relative;' class='halfWidth firstHalf'><input type='text' placeholder='First Name' value='' name='firstName' rel='mandatory' required /><label for='firstName' class='formLabel'>First Name</label></div>
								<div style='position: relative;' class='halfWidth'><input type='text' placeholder='Last Name' value='' name='lastName' rel='mandatory' required /><label for='lastName' class='formLabel'>Last Name</label></div>
								<div style='position: relative;'><input type='text' placeholder='Company Name' value='' name='companyName' required /><label for='companyName' class='formLabel'>Company Name</label></div>

								<div style='position: relative;'><input type='text' placeholder='Address' value='' name='address' rel='mandatory' required /><label for='address' class='formLabel'>Address</label></div>
								<div style='position: relative;'><input type='text' placeholder='Address Line 2' value='' name='address2' required /><label for='address2' class='formLabel'>Address Line 2</label></div>
								<div style='position: relative;'><input type='text' placeholder='Town / City' value='' name='city' rel='mandatory' required /><label for='city' class='formLabel'>Town / City</label></div>

								<div style='position: relative;' class='halfWidth firstHalf' id='stateInput2'><input type='text' placeholder='State / County' value='' name='stateInput2' rel='mandatory' required /><label for='stateInput2' class='formLabel'>State / County</label></div>
								<div style='position: relative; display: none;' class='halfWidth firstHalf' id='stateSelect2'>
									<div class='selectContainer' rel='mandatory'>
										<select name='stateSelect2' onchange="$(this).css('color', '#436178'); $('#stateSelect2_label').addClass('visible');">
											<option value='' default selected>State / County</option>
										</select>
									</div> <!-- .selectContainer -->
									<label for='stateSelect2' class='formLabel' id='stateSelect2_label'>State / County</label>
								</div>

								<div style='position: relative;' class='halfWidth'><input type='text' placeholder='Postcode / Zip' value='' name='postcode' rel='mandatory' required /><label for='postcode' class='formLabel'>Postcode / Zip</label></div>
							</div> <!-- .differentAddress -->
						</div> <!-- .paymentDetailsForm -->

						<div class='clear'></div>

						<div class='termsAndConditions'>
							<input type='checkbox' autocomplete="off" name='termsAndConditions' value='true' id='termsAndConditions' rel='mandatory' />

							<div class="checkbox">
								<label for="termsAndConditions" id='termsLabel'></label>
							</div>

							<div class="label">
								<?php
									$sql = "
									SELECT `post_content`
										FROM wp_posts
										WHERE `ID` = 400
									";
									$result = $wpdb->get_row($sql);

									$termsText = '';
									if ($wpdb->num_rows>0) {
										$termsText = str_replace('&nbsp;', '<br /><br />', $result->post_content);
									}
								?>
								<span class='checkboxText'>I have read and agree with the <a href="javascript: showModal('<div class=\'textModalInner termsAndConditionsModal\'><h2 class=\'title\'>Terms &amp; Conditions</h2><?php echo addslashes($termsText); ?></div>', 'text');">Terms &amp; Conditions</a></span>
							</div>
						</div> <!-- .termsAndConditions -->

					</div> <!-- .detailsFormContainer -->

					<div class='clear'></div>
				</div> <!-- .innerPanel -->

				<div class='errorMessage'><span>Hey, you've missed a few fields. Just finish those off and we're good to go. <img src='<?php echo $themePath; ?>images/errorArrow.png' alt='' /></span></div>

				<div class='nextButton finish' id='finishButton'>
					<a href="javascript: void(0);" onclick="validatePanel('final');"><img src='<?php echo $themePath; ?>images/buttonLoading.gif' alt='Loading' /> <span>Finish: <strong>Pay for your Print</strong></span></a>
				</div> <!-- .nextButton -->

				<div class='paymentIcons'><img src='<?php echo $themePath; ?>images/paymentIcons.png' alt='' /></div>

			</section> <!-- .uploadPanel -->




		</div> <!-- .contentWrapper -->




		<!-- PAYPAL FORM -->
		<?php // prepare values depending on if we are on sandbox or not
		$paypalSettings = get_option('woocommerce_paypal_settings');
		if($paypalSettings['testmode'] == 'yes') {
			// sandbox
			$paypalUrl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
			$paypalBusiness = 'seller-epicportraits@gmail.com';

		} else {
			// production
			$paypalUrl = 'https://www.paypal.com/cgi-bin/webscr';
			$paypalBusiness = 'tarn@epicportraits.com.au';
		}

		?>

		<form name="_xclick" action="<?php echo $paypalUrl; ?>" method="post" id='paypalForm'>
			<input type="hidden" name="cmd" value="_xclick">
			<input type="hidden" name="business" value="<?php echo $paypalBusiness; ?>">
			<input type="hidden" name="currency_code" value="AUD">
			<input type="hidden" name="item_name" value="<?php echo $title; ?>">
			<input type="hidden" name="custom" value="" id='paypalCustom'>
			<input type="hidden" name="amount" value="" id='paypalAmount'>
			<input type="hidden" name="return" value="<?php echo $sitePath; ?>order-complete/">
			<input type="hidden" name="no_shipping" value="1">
			<input type="hidden" name="notify_url" value="<?php echo $sitePath; ?>wp-content/themes/epicportraits/php/ipn.php">
		</form>




		<!-- Preload Images -->
		<img src="<?php echo $themePath; ?>images/uploadImageIcon.png" alt="" style='position: absolute; visibility: hidden; top: 0; left: 0;' />


		<?php
			// Footer
			include 'includes/footer.php';
		?>


	</body>
</html>

<?php
}
?>