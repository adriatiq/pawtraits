<!---------- NAV ---------->

<nav class='navPanel<?php if (isset($template_color)) { echo " color ".$template_color; } ?>'>
	<h2><a href="<?php if (is_front_page()) { echo "javascript: scrollTo('bannerPanel');"; } else { echo $sitePath; } ?>" class='logo'><img src='<?php echo $themePath; ?>images/logo.png' alt='Epic Portraits' /></a></h2>

	<ul class='stepNav'>
		<li>
			<a <?php if (is_front_page()) { echo "href=\"javascript: scrollTo('designsPanel');\" class='current'"; } else { echo "href='".$sitePath."#designs'"; } ?>><strong>1.</strong><span class='otherText'> Choose <strong>Design</strong></span></a>
			<div class='arrow'></div>
		</li>
		<?php
			if (is_front_page()) {
				echo "<li><div><strong>2.</strong><span class='otherText'> Review <strong>Design</strong></span></div>";
			}
			else {
				echo "<li><span id='portraitStep'><a href=\"javascript: changePanel('portraitPanel');\" class='current'><strong>2.</strong><span class='otherText'> Review <strong>Design</strong></a></span></span>";
			}
		?>
			<div class='arrow'></div>
		</li>
		<li>
			<span id='mountingStep'><div><strong>3.</strong><span class='otherText'> Choose <strong>Mounting &amp; Size</strong></span></div></span>
			<div class='arrow'></div>
		</li>
		<li>
			<span id='uploadStep'><div><strong>4.</strong><span class='otherText'> Upload <strong>Photos</strong></span></div></span>
			<div class='arrow'></div>
		</li>
		<li>
			<span id='detailsStep'><div><strong>5.</strong><span class='otherText'> Order <strong>Print</strong></span></div></span>
		</li>
	</ul> <!-- .stepNav -->

	<a href='javascript: showMenu();' class='menuButton'><span class="label">Menu</span> <button class='cmn-toggle-switch cmn-toggle-switch__htx'><span></span></button></a>

	<?php
		if (is_front_page()) {
			echo "<ul class='filterNav'>";
			echo "<li><a href=\"javascript:;\" data-filter='all' onclick=\"changeNav($(this), 'all', true);\" class='current'>All designs</a></li>";

			foreach ($all_cats as $key => $value) {
				echo "<li><a href=\"javascript:;\" data-filter='".$all_cats[$key]->slug."' onclick=\"changeNav($(this), '".$all_cats[$key]->slug."', true);\">".$all_cats[$key]->name."</a></li>";
			}

			echo "</ul> <!-- .filterNav -->";
			echo "<div class='filterDropdown' rel='mandatory'><select onchange=\"changeNav($(this), $(this).val(), true);\">";
			echo "	<option value='all'>All designs</option>";
			foreach ($all_cats as $key => $value) {
				echo "	<option value=\"".$all_cats[$key]->slug."\">".$all_cats[$key]->name."</option>";
			}
			echo "</select></div>";

		}
		else {
			echo "
				<div class='clear'></div>

				<div class='checkoutNav'>
					<div class='page'>
						<div class='text'>Your order</div>
					</div> <!-- .page -->

					<div class='portrait for_desk'>
						<div class='portraitIcon'></div>
						<div class='textContainer'>
							<div class='text'>".$title."</div>
						</div> <!-- .textContainer -->
					</div> <!-- .portrait -->

					<div class='mounting disabled for_desk'>
						<div class='mountingIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .mounting -->

					<div class='figures disabled for_desk'>
						<div class='figuresIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .figures -->

					<div class='postage disabled for_desk'>
						<div class='postageIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .postage -->

					<div class='subTotal'>
						<span class='text'>Total:</span>
						<span class='value'>$".str_replace('.', '<span>.', $price)."</span></span>
					</div> <!-- .subTotal -->

					<div class='details'><a class='text' href='javascript:void(0);'><i class='css-arrow'></i></a></div>

					<div class='couponCode for_desk' onclick=\"$(this).find('input').focus();\">
						<input type='text' value='Add coupon code' onfocus=\"if ($(this).parent().hasClass('invalid')) { $(this).parent().removeClass('invalid'); this.value = ''; } if (this.value=='Add coupon code') { this.value = ''; }\" onblur=\"if (this.value=='') { this.value = 'Add coupon code'; }\" onchange='validateCouponCode($(this).val())' />
						<div class='couponText'>20% off this purchase!</div>
					</div> <!-- .couponCode -->

					<div class='clear'></div>
					<div class='for_mob'>
					<div class='portrait'>
						<div class='portraitIcon'></div>
						<div class='textContainer'>
							<div class='text'>".$title."</div>
						</div> <!-- .textContainer -->
					</div> <!-- .portrait -->

					<div class='mounting disabled'>
						<div class='mountingIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .mounting -->

					<div class='figures disabled'>
						<div class='figuresIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .figures -->

					<div class='postage disabled'>
						<div class='postageIcon'></div>
						<div class='textContainer'>
							<div class='text'></div>
							<div class='price'></div>
						</div> <!-- .textContainer -->
					</div> <!-- .postage -->

					<div class='couponCode' onclick=\"$(this).find('input').focus();\">
						<input type='text' value='Add coupon code' onfocus=\"if ($(this).parent().hasClass('invalid')) { $(this).parent().removeClass('invalid'); this.value = ''; } if (this.value=='Add coupon code') { this.value = ''; }\" onblur=\"if (this.value=='') { this.value = 'Add coupon code'; }\" onchange='validateCouponCode($(this).val())' />
						<div class='couponText'>20% off this purchase!</div>
					</div> <!-- .couponCode -->
					</div>
					<div class='clear'></div>
				</div>
			";

			// show waiting message if filled in
			if(get_field('waiting_message', 'option')) {
				echo '<div id="waiting-message">
						<span class="close"></span>
						<p>
							' . get_field('waiting_message', 'option') . '
						</p>
					</div>';
			}
		}
	?>

	<div class='clear'></div>
</nav>