<?php
	// Setup PHP params
	error_reporting(E_ALL);
	ini_set('display_errors', 'On');
	ini_set('allow_url_fopen', 'On');

	// Make sure $_GET passes in correctly
	parse_str($_SERVER['QUERY_STRING'], $_GET);

	// Setup pathing
	$sitePath = get_site_url().'/';
	$themePath = get_theme_root_uri().'/epicportraits/';
	$includesPath = includes_url();
	$pluginsPath = plugins_url().'/';
?>
<html>
	<head>
		<title><?php echo get_bloginfo('name'); ?></title>

		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >

		<!-- CSS -->
		<link rel="stylesheet" href="<?php echo $themePath; ?>css/style.css">
		<link rel='stylesheet' id='layerslider-css'  href='<?php echo $pluginsPath; ?>LayerSlider/static/css/layerslider.css?ver=5.1.1' type='text/css' media='all' />

		<link rel="stylesheet" type="text/css" href="<?php echo $themePath; ?>css/ie.css" />

		<!-- JS -->
		<script type='text/javascript' src='<?php echo $includesPath; ?>js/jquery/jquery.js'></script>
		<script type='text/javascript' src='<?php echo $includesPath; ?>js/jquery/jquery.easing.1.3.js'></script>
		<script type='text/javascript' src='<?php echo $includesPath; ?>js/jquery/jquery.masonry.min.js'></script>

		<?php /*
		<script type="text/javascript" src="<?php echo $includesPath; ?>js/retina-1.1.0.js"></script>
		*/?>

		<script type='text/javascript' src='<?php echo $pluginsPath; ?>LayerSlider/static/js/layerslider.kreaturamedia.jquery.js?ver=5.1.1'></script>
		<script type='text/javascript' src='<?php echo $pluginsPath; ?>LayerSlider/static/js/greensock.js?ver=1.11.2'></script>
		<script type='text/javascript' src='<?php echo $pluginsPath; ?>LayerSlider/static/js/layerslider.transitions.js?ver=5.1.1'></script>

		<script type="text/javascript" src="<?php echo $themePath; ?>js/general.js"></script>
		<script type='text/javascript' src='<?php echo $themePath; ?>js/lib/jquery.json.js'></script>

		<script type='text/javascript'>
			var sitePath = '<?php echo $sitePath; ?>';
			var themePath = '<?php echo $themePath; ?>';
			var includesPath = '<?php echo $includesPath; ?>';
			var pluginsPath = '<?php echo $pluginsPath; ?>';
			var ajax_url = '<?php echo admin_url( "admin-ajax.php" ); ?>';
		</script>

		<!-- Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

		<!-- Page Specific -->
