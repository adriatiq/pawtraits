<!---------- NAV ---------->

<nav class='navPanel<?php if (isset($template_color)) { echo " color ".$template_color; } ?>'>
	<h2><a href="<?php if (is_front_page()) { echo "javascript: scrollTo('bannerPanel');"; } else { echo $sitePath; } ?>" class='logo'><img src='<?php echo $themePath; ?>images/logo.png' alt='Epic Portraits' /></a></h2>

	<a href='javascript: showMenu();' class='menuButton'>Menu <div class='icon'></div></a>

	<div class='clear'></div>
</nav>