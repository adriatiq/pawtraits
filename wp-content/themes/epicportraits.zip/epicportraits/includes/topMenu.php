<!---------- TOP MENU ---------->

<ul class='topMenu'>
	<?php
		$args = array(
			'theme_location'  => '',
			'menu'            => '34',
			'container'       => 'a',
			'container_class' => '',
			'container_id'    => '',
			'menu_class'      => 'menu',
			'menu_id'         => '',
			'echo'            => true,
			'fallback_cb'     => '',
			'before'          => '',
			'after'           => '',
			'link_before'     => '',
			'link_after'      => '',
			'items_wrap'      => '%3$s',
			'depth'           => 0,
			'walker'          => ''
		);
		
		wp_nav_menu($args);
		
		if (is_front_page()) {
			echo "<li><a href=\"javascript: scrollTo('designsPanel');\" class='topBrowseButton'>Get your own portrait</a></li>";
		}
		else {
			echo "<li><a href=\"".$sitePath."#designs\">Get your own portrait</a></li>";
		}
	?>
</ul> <!-- .topMenu -->