	<!---------- MODAL ---------->
	
	<div class='modal'>
		<div class='modalBackground' onclick="hideModal();"></div>
		<a href='javascript: hideModal();' class='crossIcon'><img src='<?php echo $themePath; ?>images/crossIcon.png' alt='Close' /></a>
		
		<table style="width: 100%; height: 100%;">
			<tr>
					<td style="text-align: center; vertical-align: middle;">
						<div class='modalContent'></div>
					</td>
			</tr>
		</table>
	</div> <!-- .modal -->