<?php
	// Setup WooCommerce & Wordpress
	require_once("../../../../wp-load.php");
	require_once("../../../plugins/woocommerce/woocommerce.php");
	
	

	// Function to convert object to array
	function objectToArray($object) {
		if(!is_object($object) && !is_array($object)) {
			return $object;
		}
		return array_map('objectToArray', (array) $object);
	}
	
	// Get out the order data passed to this file
	$order = objectToArray(json_decode(file_get_contents("php://input")));
	$data = $order['order'];
	
	
	// Get the mounting cost and shipping cost
	$sql = "
		SELECT `option_value`
		FROM wp_options
		WHERE `option_name` = 'wc_settings_tab_mounting_".$data['mounting']['type']."'
		OR `option_name` = 'wc_settings_tab_shipping_local'
		OR `option_name` = 'wc_settings_tab_shipping_international'
		ORDER BY `option_name` DESC
	";
	$result = mysql_query($sql);
	
	$localDelivery = mysql_result($result, 0, 'option_value');
	$internationalDelivery = mysql_result($result, 1, 'option_value');
	$mountingString = mysql_result($result, 2, 'option_value');
	
	$tmp = explode(str_replace('mm', '', str_replace(' ', '', $data['mounting']['size'])).'|', $mountingString);
	$tmp = explode('|', $tmp[1]);
	$mountingPrice = $tmp[0];
	$mountingPostage = preg_split('/$\R?^/m', $tmp[1]);
	$mountingPostage = $mountingPostage[0];
	
	
	// Get the price per figure
	$meta = get_post_meta($data['id']);
	$pricePerFigure = $meta['price_per_figure'][0];
	
	
	// Get the price
	$product = new WC_Product($data['id']);
	if ($product->price) {
		$price = number_format($product->price, 2);
	}
	else {
		$price = 0;
	}
	
	
	// Setup the billing address
	$billingAddress = array();
	foreach($data['customerDetails']['billingAddress'] as $key=>$value) {
		if ($key=='firstName') {
			$billingAddress['first_name'] = $value;
		}
		else if ($key=='lastName') {
			$billingAddress['last_name'] = $value;
		}
		else if ($key=='address') {
			$billingAddress['address_1'] = $value;
		}
		else if ($key=='address2') {
			$billingAddress['address_2'] = $value;
		}
		else if ($key=='companyName') {
			$billingAddress['company'] = $value;
		}
		else {
			$billingAddress[$key] = $value;
		}
	}
	
	// Setup the shipping address
	$shippingAddress = array();
	foreach($data['customerDetails']['shippingAddress'] as $key=>$value) {
		if ($key=='firstName') {
			$shippingAddress['first_name'] = $value;
		}
		else if ($key=='lastName') {
			$shippingAddress['last_name'] = $value;
		}
		else if ($key=='address') {
			$shippingAddress['address_1'] = $value;
		}
		else if ($key=='address2') {
			$shippingAddress['address_2'] = $value;
		}
		else if ($key=='companyName') {
			$shippingAddress['company'] = $value;
		}
		else {
			$shippingAddress[$key] = $value;
		}
	}
	
	
	
	// Create the order
	// ------------------------------------------------------------------
	$order = wc_create_order();
	
	$order->add_product(get_product($data['id']), 1);
	$order->set_address($billingAddress, 'billing');
	$order->set_address($shippingAddress, 'shipping');
	
	
	
	
	
	// Calculate the total figures
	$totalFigures = 0;
	for ($i=0; $i<count($data['figurePortraitDetails']); $i++) {
		$tmp = count($data['figurePortraitDetails'][$i]);
		if ($tmp==0) {
			$tmp = 1;
		}
		$totalFigures += $tmp;
	}
	
	
	
	// Calculate the shipping
	$shipping = $mountingPostage;
	if ($shippingAddress['country']=='AU') {
		$shipping += $localDelivery;
	}
	else {
		$shipping += $internationalDelivery;
	}
	
	
	
	// Validate coupon, calculate discount, attach coupon 
	$discount = 0;
	if ($data['coupon']!='') {
		$sql = "
			SELECT a.post_title, b.meta_key, b.meta_value
			FROM wp_posts a, wp_postmeta b
			WHERE a.post_type = 'shop_coupon'
			AND a.id = b.post_id
			AND (b.meta_key = 'free_shipping'
				OR b.meta_key = 'discount_type'
				OR b.meta_key = 'coupon_amount'
				OR b.meta_key = 'expiry_date'
				OR b.meta_key = 'usage_count'
				OR b.meta_key = 'usage_limit'
				OR b.meta_key = 'exclude_sale_items'
				OR b.meta_key = 'product_categories'
				OR b.meta_key = 'exclude_product_categories'
				OR b.meta_key = 'product_ids'
				OR b.meta_key = 'exclude_product_ids'
			)
			AND a.post_title = '".sanitize_text_field($data['coupon'])."'
			ORDER BY a.post_title, b.meta_key DESC
		";
		$result = mysql_query($sql);
		
		if (mysql_num_rows($result)>0) {
			
			
			$couponDetails = array();
			for ($z=0; $z<mysql_num_rows($result); $z++) {
				$coupon_code = mysql_result($result, $z, 'post_title');
				$meta_key = mysql_result($result, $z, 'meta_key');
				$meta_value = mysql_result($result, $z, 'meta_value');
				
				$meta_value = str_replace('_cart', '', $meta_value);
				
				if ($meta_key=='expiry_date') {
					$meta_value = str_replace('-', '', $meta_value);
				}
				
				$coupon = new WC_Coupon($coupon_code);
				$couponDetails[$meta_key] = $meta_value;
			}
			
			
			
			
			
			function validateCoupon() {
				global $data;
				global $couponDetails;
				
				
				
				
				$cat_arr = wp_get_post_terms($data['id'], 'product_cat');
				$categories = array();
				for ($z=0; $z<count($cat_arr); $z++) {
					array_push($categories, $cat_arr[$z]->term_id);
				}
				
				
				
				// If NOT in included categories = fail
				if ($couponDetails['product_categories']!='a:0:{}') {
					$inc_cats = explode('i:', $couponDetails['product_categories']);
					$tmp = array();
					for ($i=0; $i<count($inc_cats); $i++) {
						$inc_cats[$i] = str_replace(';', '', $inc_cats[$i]);
						$inc_cats[$i] = str_replace('}', '', $inc_cats[$i]);
						if ($i!=0 && $i%2==0) {
							array_push($tmp, $inc_cats[i]);
						}
					}
					$inc_cats = $tmp;
					
					$valid = false;
					
					for ($i=0; $i<count($inc_cats); $i++) {
						if (in_array($inc_cats[i], $categories)!==-1) {
							$valid = true;
						}
					}
					
					if ($valid===false) {
						return false;
					}
				}
				
				
				// If IN excluded products = fail
				if ($couponDetails['exclude_product_categories']!='a:0:{}') {
					$inc_cats = explode('i:', $couponDetails['exclude_product_categories']);
					$tmp = array();
					for ($i=0; $i<count($inc_cats); $i++) {
						$inc_cats[$i] = str_replace(';', '', $inc_cats[$i]);
						$inc_cats[$i] = str_replace('}', '', $inc_cats[$i]);
						if ($i!=0 && $i%2==0) {
							array_push($tmp, $inc_cats[i]);
						}
					}
					$inc_cats = $tmp;
					
					$valid = true;
					
					for ($i=0; $i<count($inc_cats); $i++) {
						if (in_array($inc_cats[i], $categories)!==-1) {
							$valid = false;
						}
					}
					
					if ($valid===false) {
						return false;
					}
				}
				
				
				
				
				
				
				// Usage limit
				if ($couponDetails['usage_count']>=$couponDetails['usage_limit'] && $couponDetails['usage_limit']>0 && $couponDetails['usage_limit']!='') {
					return false;
				}
				// Exp date
				else if ($couponDetails['expiry_date']<date('Y-m-d') && $couponDetails['expiry_date']!='') {
					return false;
				}
				// On sale
				else if ($couponDetails['exclude_sale_items']=='yes' && on_sale===true) {
					return false;
				}
				// On sale
				else if ($couponDetails['exclude_sale_items']=='yes' && on_sale===true) {
					return false;
				}
				// If NOT in included products = fail
				else if ($couponDetails['product_ids']!='' && strpos($couponDetails['product_ids'], $data['id'])===false) {
					return false;
				}
				// If IN excluded products = fail
				else if ($couponDetails['exclude_product_ids']!='' && strpos($couponDetails['exclude_product_ids'], $data['id'])===false) {			
					return false;
				}
				else {
					return true;
				}
				
			}
			
			
			if (validateCoupon()===true) {
				
				
				if ($couponDetails['discount_type']=='percent') {
					$totalNoShipping = $price+$mountingPrice+($pricePerFigure*$totalFigures);
					$discount = ($totalNoShipping/100)*$couponDetails['coupon_amount'];
				}
				else {
					$discount = $couponDetails['coupon_amount'];
				}
				if ($couponDetails['free_shipping']=='yes') {
					$shipping = 0;
				}
				
				
				
				$order->add_coupon(sanitize_text_field($data['coupon']), $discount);
			}
		}
	}
	
	
	
	// Calculate the order total
	$total = ($price+$mountingPrice+($pricePerFigure*$totalFigures))-$discount;
	if ($total<0) {
		$total = 0;
	}
	
	$total += $shipping;
	
	
	// Add the discount
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_discount', '".$discount."')
	";
	$result = mysql_query($sql);
	
	
	// Add the mounting
	$sql = "
		INSERT INTO wp_woocommerce_order_items(order_item_name, order_item_type, order_id)
		VALUES('Mounting (".ucfirst($data['mounting']['type'])." - ".str_replace('x', ' x ', $data['mounting']['size']).")', 'fee', ".$order->id.")
	";
	$result = mysql_query($sql);
	$orderItemId = mysql_insert_id();
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_total', '".$mountingPrice."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_subtotal', '".$mountingPrice."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_tax', '0')
	";
	$result = mysql_query($sql);
	
	
	// Add the figures
	$sql = "
		INSERT INTO wp_woocommerce_order_items(order_item_name, order_item_type, order_id)
		VALUES('Figures (".$totalFigures.")', 'fee', ".$order->id.")
	";
	$result = mysql_query($sql);
	$orderItemId = mysql_insert_id();
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_total', '".($pricePerFigure*$totalFigures)."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_subtotal', '".($pricePerFigure*$totalFigures)."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_tax', '')
	";
	$result = mysql_query($sql);
	
	
	// Add the shipping
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_shipping', '".$shipping."')
	";
	$result = mysql_query($sql);
	
	
	// Add the total
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_total', '".$total."')
	";
	$result = mysql_query($sql);
	
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_tax', 0)
	";
	$result = mysql_query($sql);
	
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_shipping_tax', 0)
	";
	$result = mysql_query($sql);
	
	
	
	// Add Image Details
	$imageDetails = '';
	
	$i = 1;
	foreach($data['figurePortraitDetails'] as $key=>$value) {
		$imageDetails .= 'Image '.$i.' -
Name: '.$data['uploadedImages'][$key]['name'].'
Link: '.$data['uploadedImages'][$key]['url'].'
--------------------------------------------------------------------------
';
		$i++;
		
		$z = 1;
		foreach($data['figurePortraitDetails'][$key] as $key2=>$value2) {
			$imageDetails .= 'Figure '.$z.' -
';
			$z++;
			
			foreach($data['figurePortraitDetails'][$key][$key2] as $key3=>$value3) {
		$imageDetails .= $key3.":
".$value3."

";
			}
		}
		
		$imageDetails .= '
';
	}
	
	if ($imageDetails!='') {
		$sql = "
			INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
			VALUES(".$order->id.", '(Image Details', '".$imageDetails."')
		";
		$result = mysql_query($sql);
	}
	
	
	
	// Add the General Portrait Details
	$generalPortraitDetails = '';
	
	foreach($data['generalPortraitFields'] as $key=>$value) {
		$generalPortraitDetails .= $key.":
".$value."

";
	}
	
	if ($generalPortraitDetails!='') {
		$sql = "
			INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
			VALUES(".$order->id.", 'General Portrait Details', '".$generalPortraitDetails."')
		";
		$result = mysql_query($sql);
	}
	
	
	// Output the required stuff for Paypal
	echo $order->id.'|-|-|'.$total.'|-|-|'.md5('ak970'.$total.$order->id.'b709u');
?>