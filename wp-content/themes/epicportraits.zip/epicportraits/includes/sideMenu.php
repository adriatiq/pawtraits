<!---------- SIDE MENU ---------->

<div class='sideMenu'>
	<ul>
		<?php 
			if (is_front_page()) {
				echo "
					<li class='current-menu-item'><a href=\"javascript: setCurrentMenu('homeButton'); scrollTo('bannerPanel');\" class='homeButton'>Home</a></li>
					<li><a href=\"javascript: setCurrentMenu('designsButton'); scrollTo('designsPanel');\" class='designsButton'>Browse portrait designs</a></li>
				";
			}
			else {
				echo "
					<li><a href='".$sitePath."' class='homeButton'>Home</a></li>
					<li><a href='".$sitePath."#designs' class='designsButton'>Browse portrait designs</a></li>
				";
			}
			
			$args = array(
				'theme_location'  => '',
				'menu'            => '13',
				'container'       => 'li',
				'container_class' => '',
				'container_id'    => '',
				'menu_class'      => 'menu',
				'menu_id'         => '',
				'echo'            => true,
				'fallback_cb'     => 'wp_page_menu',
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '%3$s',
				'depth'           => 0,
				'walker'          => ''
			);
			
			wp_nav_menu($args);

			echo "
				<li><a href=\"javascript: showModal('<div class=\\'textModalInner portraitIdeaModal\\'><h2 class=\\'title\\'>Got a portrait idea?</h2><div style=\\'position: relative;\\'><input type=\\'text\\' placeholder=\\'Name\\' value=\\'\\' name=\\'name\\' rel=\\'mandatory\\' required /><label for=\\'name\\' class=\\'formLabel\\'>Name</label></div><div style=\\'position: relative;\\'><input type=\\'text\\' placeholder=\\'Email\\' value=\\'\\' name=\\'email\\' rel=\\'mandatory\\' required /><label for=\\'email\\' class=\\'formLabel\\'>Email</label></div><div style=\\'position: relative;\\'><textarea placeholder=\\'Your portrait idea\\' rel=\\'mandatory\\' name=\\'portraitIdea\\' required></textarea><label for=\\'portraitIdea\\' class=\\'formLabel\\'>Portrait Idea</label></div><a href=\\'javascript: submitPortraitIdea();\\' class=\\'submitButton\\'>Submit idea</a></div>', 'text');\">Got a portrait idea?</a></li>
			";
		?>
		
	</ul>
</div> <!-- .sideMenu -->