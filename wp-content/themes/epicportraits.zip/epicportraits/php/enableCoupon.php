<?php
	// Setup WooCommerce & Wordpress
	require_once("../../../../wp-load.php");

	// Ensure all post vars are here
	if (isset($_POST['id']) && isset($_POST['key']) && isset($_POST['coupon'])) {
		// And that the key is valid
		if ($_POST['key'] == md5('akz78'.$_POST['coupon'].$_POST['id'].'pq98bv')) {
			// Check if this coupon code already exists in the database for this order
			$sql = "
				SELECT `post_content`
				FROM wp_posts
				WHERE `ID` = '".mysql_real_escape_string($_POST['id'])."'
			";
			$result = mysql_query($sql);

			if (mysql_num_rows($result)==1) {
				$couponCode = mysql_result($result, 0, 'post_content');

				// If it doesn't already exist
				if ($couponCode=='') {
					// Add the coupon code to the database
					$sql = "
						INSERT INTO wp_posts(
							`post_author`,
							`post_date`,
							`post_date_gmt`,
							`post_content`,
							`post_title`,
							`post_excerpt`,
							`post_status`,
							`comment_status`,
							`ping_status`,
							`post_password`,
							`post_name`,
							`to_ping`,
							`pinged`,
							`post_modified`,
							`post_modified_gmt`,
							`post_content_filtered`,
							`post_parent`,
							`guid`,
							`menu_order`,
							`post_type`,
							`post_mime_type`,
							`comment_count`
						)
						VALUES(
							1,
							'".date('Y-m-d H:i:s')."',
							'".date('Y-m-d H:i:s')."',
							'',
							'".mysql_real_escape_string($_POST['coupon'])."',
							'Shared on Social Media - Order #".mysql_real_escape_string($_POST['id'])."',
							'publish',
							'closed',
							'closed',
							'',
							'".mysql_real_escape_string($_POST['coupon'])."',
							'',
							'',
							'".date('Y-m-d H:i:s')."',
							'".date('Y-m-d H:i:s')."',
							'',
							0,
							'',
							0,
							'shop_coupon',
							'',
							0
						)
					";
					$result = mysql_query($sql);
					$couponID = mysql_insert_id();

					// expiry_date
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'expiry_date',
							'".date('Y-m-d', strtotime('+1 month'))."'
						)
					";
					$result = mysql_query($sql);

					// usage_limit
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'usage_limit',
							'1'
						)
					";
					$result = mysql_query($sql);

					// exclude_product_ids
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'exclude_product_ids',
							''
						)
					";
					$result = mysql_query($sql);

					// product_ids
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'product_ids',
							''
						)
					";
					$result = mysql_query($sql);

					// individual_use
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'individual_use',
							'no'
						)
					";
					$result = mysql_query($sql);

					// coupon_amount
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'coupon_amount',
							'10'
						)
					";
					$result = mysql_query($sql);

					// discount_type
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'discount_type',
							'percent_product'
						)
					";
					$result = mysql_query($sql);

					// usage_count
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'usage_count',
							'0'
						)
					";
					$result = mysql_query($sql);

					// minimum_amount
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'minimum_amount',
							''
						)
					";
					$result = mysql_query($sql);

					// maximum_amount
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'maximum_amount',
							''
						)
					";
					$result = mysql_query($sql);

					// customer_email
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'customer_email',
							'a:0:{}'
						)
					";
					$result = mysql_query($sql);

					// exclude_product_categories
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'exclude_product_categories',
							'a:0:{}'
						)
					";
					$result = mysql_query($sql);

					// product_categories
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'product_categories',
							'a:0:{}'
						)
					";
					$result = mysql_query($sql);

					// free_shipping
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'free_shipping',
							'no'
						)
					";
					$result = mysql_query($sql);

					// exclude_sale_items
					$sql = "
						INSERT INTO wp_postmeta(
							`post_id`,
							`meta_key`,
							`meta_value`
						)
						VALUES(
							'".mysql_real_escape_string($couponID)."',
							'exclude_sale_items',
							'no'
						)
					";
					$result = mysql_query($sql);




					// And update this order to have the coupon code
					$sql = "
						UPDATE wp_posts
						SET `post_content` = '".mysql_real_escape_string($_POST['coupon'])."'
						WHERE `ID` = '".mysql_real_escape_string($_POST['id'])."'
					";
					$result = mysql_query($sql);
				}






				// Send out a "Thank you" email
				$sql_email = "
					SELECT `meta_value`
					FROM wp_postmeta
					WHERE (
						`meta_key` = '_billing_email'
						OR `meta_key` = '_billing_first_name'
						OR `meta_key` = '_billing_last_name'
					)
					AND `post_id` = '".mysql_real_escape_string($_POST['id'])."'
					ORDER BY `meta_key` ASC
				";
				$result_email = mysql_query($sql_email);

				if (mysql_num_rows($result_email)>0) {

					$to = mysql_result($result_email, 0, 'meta_value');
					$firstName = mysql_result($result_email, 1, 'meta_value');
					$lastName = mysql_result($result_email, 2, 'meta_value');
					$subject = 'Thanks for sharing!';


					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .= 'To: '.$firstName.' '.$lastName.' <'.$to.'>' . "\r\n";
					$headers .= 'From: Epic Portraits <noreply@epicportraits.com>' . "\r\n";


					$message = '
						<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"><tbody><tr><td align="center" valign="top">
												<div>
							          	<img src="https://ci5.googleusercontent.com/proxy/-YaAKdBVEfRVQB3NDLQrwPIPIEFvvFG9HQbheFSXCTK9gSOCRA4QPmW5N3ZGb_mvtq2GEQoxOubbG0Y1mpgCJcwOrv2bJXE3ZdGeh8tcEjVerS4y5bsAqHwLMi7VnV7XiSivdcJOoTMLvoPU6SAcanFnWxQ=s0-d-e1-ft#http://designlift.co/epicportraits/wp-content/themes/epicportraits/images/emailBanner.jpg?i=10" alt="" style="padding-bottom:7px" class="CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 654.5px; top: 205px;"><div id=":np" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download"><div class="aSK J-J5-Ji aYr"></div></div></div></div>
						                    	<table border="0" cellpadding="0" cellspacing="0" width="600"><tbody><tr><td align="center" valign="top">

						                                	<table border="0" cellpadding="0" cellspacing="0" width="600"><tbody><tr><td valign="top">

						                                                <table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top">
						                                                            <div>


						<table cellspacing="0" cellpadding="10" style="width: 100%; font-family: arial, sans-serif;" border="0">
							<tbody>
								<tr>
									<td valign="top" colspan="2">
										<div style="font-size: 34px; font-weight: 700; color: #436178;">Thanks for sharing your Epic Portrait!</div>

						        <div style="font-size: 14px; font-weight: 700; color: #436178;"><br />Use the coupon code below within the next month to get 10% off:</div>
						        <div style="font-size: 24px; font-weight: 700; color: #436178;">'.$_POST['coupon'].'</div>

									</td>
								</tr>

							</tbody>
						</table>




						</div>
																				</td>
						                                                    </tr></tbody></table></td>
						                                        </tr></tbody></table></td>

						                        	</tr><tr><td align="center" valign="top">

						                                	<table border="0" cellpadding="10" cellspacing="0" width="600" style="border-top:0"><tbody><tr><td valign="top">
						                                                <table border="0" cellpadding="10" cellspacing="0" width="100%"><tbody><tr><td colspan="2" valign="middle" style="border:0;color:#8ea0ae;font-family:Arial;font-size:12px;line-height:125%;text-align:center">
						                                                        	<p>&copy; Epic Portraits, '.date('Y').'</p>
						                                                        </td>
						                                                    </tr></tbody></table></td>
						                                        </tr></tbody></table></td>
						                            </tr></tbody></table></td>
						                </tr></tbody></table>
					';

					// Mail it
					mail($to, $subject, $message, $headers);
				}

			}
			else {
				// This order doesn't exist? So exit.
				exit();
			}



		}
	}
?>