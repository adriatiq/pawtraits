<?php
// Setup WooCommerce & Wordpress
require_once("../../../../wp-load.php");

$name = $_POST['name'];
$email = $_POST['email'];
$portraitIdea = $_POST['portraitIdea'];

$message = '
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"><tbody><tr><td align="center" valign="top">
						<div>
	          	<img src="https://ci5.googleusercontent.com/proxy/-YaAKdBVEfRVQB3NDLQrwPIPIEFvvFG9HQbheFSXCTK9gSOCRA4QPmW5N3ZGb_mvtq2GEQoxOubbG0Y1mpgCJcwOrv2bJXE3ZdGeh8tcEjVerS4y5bsAqHwLMi7VnV7XiSivdcJOoTMLvoPU6SAcanFnWxQ=s0-d-e1-ft#http://designlift.co/epicportraits/wp-content/themes/epicportraits/images/emailBanner.jpg?i=10" alt="" style="padding-bottom:7px" class="CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 654.5px; top: 205px;"><div id=":np" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download"><div class="aSK J-J5-Ji aYr"></div></div></div></div>
                    	<table border="0" cellpadding="0" cellspacing="0" width="600"><tbody><tr><td align="center" valign="top">
                                    
                                	<table border="0" cellpadding="0" cellspacing="0" width="600"><tbody><tr><td valign="top">
                                                
                                                <table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top">
                                                            <div>


<table cellspacing="0" cellpadding="10" style="width: 100%; font-family: arial, sans-serif;" border="0">
	<tbody>
		<tr>
			<td valign="top" colspan="2">
				<div style="font-size: 34px; font-weight: 700; color: #436178;">New portrait idea</div>

                <div style="font-size: 14px; font-weight: 700; color: #436178;"><br />Name -</div>
                <div style="font-size: 14px; font-weight: 400; color: #436178;">'.$name.'</div>

                <div style="font-size: 14px; font-weight: 700; color: #436178;"><br />Email -</div>
                <div style="font-size: 14px; font-weight: 400; color: #436178;"><a href="mailto:'.$_POST['email'].'">'.$email.'</a></div>

                <div style="font-size: 14px; font-weight: 700; color: #436178;"><br />Portrait idea -</div>
                <div style="font-size: 14px; font-weight: 400; color: #436178;">'.$portraitIdea.'</div>
			</td>
		</tr>

	</tbody>
</table>




</div>
														</td>
                                                    </tr></tbody></table></td>
                                        </tr></tbody></table></td>
                            
                        	</tr><tr><td align="center" valign="top">
                                    
                                	<table border="0" cellpadding="10" cellspacing="0" width="600" style="border-top:0"><tbody><tr><td valign="top">
                                                <table border="0" cellpadding="10" cellspacing="0" width="100%"><tbody><tr><td colspan="2" valign="middle" style="border:0;color:#8ea0ae;font-family:Arial;font-size:12px;line-height:125%;text-align:center">
                                                        	<p>&copy; Epic Portraits, '.date('Y').'</p>
                                                        </td>
                                                    </tr></tbody></table></td>
                                        </tr></tbody></table></td>
                            </tr></tbody></table></td>
                </tr></tbody></table>
';


// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$to = get_option('admin_email');
$subject = 'New portrait idea';

// Additional headers
$headers .= 'To: Epic Portraits <'.$to.'>' . "\r\n";
$headers .= 'From: '.$name.' <'.$email.'>' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);

?>