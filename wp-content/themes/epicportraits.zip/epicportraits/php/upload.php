<?php
$ds = DIRECTORY_SEPARATOR;

$storeFolder = '../../../uploads/portraits';

if (!empty($_FILES)) {
	$tempFile = $_FILES['file']['tmp_name'];

	// check by finfo
	if(function_exists('finfo_open')) {
		$finfo = finfo_open(FILEINFO_MIME_TYPE);
		$ft = explode('/', finfo_file($finfo, $tempFile));
		if(is_array($ft) && $ft[0] != 'image') die('unsupported image type');

	// check if it is image by get_image_size
	} elseif(!@is_array(getimagesize($tempFile))) {
		die('unsupported image type');
	}

	$targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;
	$targetFile =  $targetPath.$_GET['unique'].'-'.$_FILES['file']['name'];
	move_uploaded_file($tempFile,$targetFile);

}
?>