<?php
	$ds = DIRECTORY_SEPARATOR;
	$storeFolder = '../../../uploads/portraits';

	// sanitize data not to contain any PHP or path information to delete something else
	$file = $_GET['unique'].'-'.$_POST['name'];
	$file = basename(htmlspecialchars($file));

	$targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;
	$targetFile =  $targetPath.$file;

	unlink($targetFile);
?>