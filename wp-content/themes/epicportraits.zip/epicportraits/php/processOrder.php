<?php
	// Setup WooCommerce & Wordpress
	require_once("../../../../wp-load.php");
	require_once("../../../plugins/woocommerce/woocommerce.php");


	// Function to convert object to array
	function objectToArray($object) {
		if(!is_object($object) && !is_array($object)) {
			return $object;
		}
		return array_map('objectToArray', (array) $object);
	}

	// Get out the order data passed to this file
	$order = objectToArray(json_decode(file_get_contents("php://input")));
	$data = $order['order'];

	// sign to Mailchimp if newsletter checkbox checked
	if($data['newsletterSignup']) {
		// Load Mailchimp class
		require_once(__DIR__ . DIRECTORY_SEPARATOR . "MailChimp.php");
		$mailchimp_cfg = array(
			'api_key' => '811156f3b8c6381b087e2ee16d0726dd-us12',
			'list_id' => '594e7da9e3',
			'double_optin'		=> false,
			'send_welcome'		=> false,
		);

		//proceed with submission to the mailchimp api
		$MailChimp = new \Drewm\MailChimp( $mailchimp_cfg['api_key'] );
		$result = $MailChimp->call('lists/subscribe', array(
			'id'                => $mailchimp_cfg['list_id'],
			'email'             => array('email'=> $data['customerDetails']['billingAddress']['email']),
			'merge_vars'        => array('FNAME'=> $data['customerDetails']['billingAddress']['firstName'], 'LNAME'=> $data['customerDetails']['billingAddress']['lastName']),
			'double_optin'      => $mailchimp_cfg['double_optin'],
			'update_existing'   => true,
			'replace_interests' => false,
			'send_welcome'      => $mailchimp_cfg['send_welcome'],
		));
	}

	// Get the mounting cost and shipping cost
	$sql = "
		SELECT `option_value`
		FROM wp_options
		WHERE `option_name` = 'wc_settings_tab_mounting_".$data['mounting']['type']."'
		OR `option_name` = 'wc_settings_tab_shipping_local'
		OR `option_name` = 'wc_settings_tab_shipping_international'
		ORDER BY `option_name` DESC
	";
	$result = mysql_query($sql);

	$localDelivery = mysql_result($result, 0, 'option_value');
	$internationalDelivery = mysql_result($result, 1, 'option_value');
	$mountingString = mysql_result($result, 2, 'option_value');

	$tmp = explode(str_replace('mm', '', str_replace(' ', '', $data['mounting']['size'])).'|', $mountingString);
	$tmp = explode('|', $tmp[1]);
	$mountingPrice = $tmp[0];
	$mountingPostage = preg_split('/$\R?^/m', $tmp[1]);
	$mountingPostage = $mountingPostage[0];


	// Get the price per figure
	$meta = get_post_meta($data['id']);
	$pricePerFigure = $meta['price_per_figure'][0];


	// Get the price
	$product = new WC_Product($data['id']);
	if ($product->price) {
		$price = number_format($product->price, 2);
	}
	else {
		$price = 0;
	}


	// Setup the billing address
	$billingAddress = array();
	foreach($data['customerDetails']['billingAddress'] as $key=>$value) {
		if ($key=='firstName') {
			$billingAddress['first_name'] = $value;
		}
		else if ($key=='lastName') {
			$billingAddress['last_name'] = $value;
		}
		else if ($key=='address') {
			$billingAddress['address_1'] = $value;
		}
		else if ($key=='address2') {
			$billingAddress['address_2'] = $value;
		}
		else if ($key=='companyName') {
			$billingAddress['company'] = $value;
		}
		else {
			$billingAddress[$key] = $value;
		}
	}

	// Setup the shipping address
	$shippingAddress = array();
	foreach($data['customerDetails']['shippingAddress'] as $key=>$value) {
		if ($key=='firstName') {
			$shippingAddress['first_name'] = $value;
		}
		else if ($key=='lastName') {
			$shippingAddress['last_name'] = $value;
		}
		else if ($key=='address') {
			$shippingAddress['address_1'] = $value;
		}
		else if ($key=='address2') {
			$shippingAddress['address_2'] = $value;
		}
		else if ($key=='companyName') {
			$shippingAddress['company'] = $value;
		}
		else {
			$shippingAddress[$key] = $value;
		}
	}

	// Create the order
	// ------------------------------------------------------------------
	$order = wc_create_order();

	$order->add_product(get_product($data['id']), 1);
	$order->set_address($billingAddress, 'billing');
	$order->set_address($shippingAddress, 'shipping');





	// Calculate the total figures
	$totalFigures = 0;
	for ($i=0; $i<count($data['figurePortraitDetails']); $i++) {
		$tmp = count($data['figurePortraitDetails'][$i]);
		if ($tmp==0) {
			$tmp = 1;
		}
		$totalFigures += $tmp;
	}



	// Calculate the shipping
	$shipping = $mountingPostage;
	if ($shippingAddress['country']=='AU') {
		$shipping += $localDelivery;
	}
	else {
		$shipping += $internationalDelivery;
	}



	// Validate coupon, calculate discount, attach coupon
	$discount = 0;
	if ($data['coupon']!='') {
		$loaded_coupon = my_load_coupon($data['coupon']);
		if($loaded_coupon['status'] === true) {
			$couponDetails = $loaded_coupon['coupon'];

			function validateCoupon() {
				global $data;
				global $couponDetails;


				$cat_arr = wp_get_post_terms($data['id'], 'product_cat');
				$categories = array();
				for ($z=0; $z<count($cat_arr); $z++) {
					array_push($categories, $cat_arr[$z]->term_id);
				}


				// If NOT in included categories = fail
				if (!empty($couponDetails['product_categories'])) {
					$valid = false;

					foreach($couponDetails['product_categories'] as $c) {
						if (in_array($c, $categories)) $valid = true;
					}

					if ($valid===false) return false;
				}


				// If IN excluded products = fail
				if (!empty($couponDetails['exclude_product_categories'])) {
					$valid = true;

					foreach ($couponDetails['exclude_product_categories'] as $c) {
						if (in_array($c, $categories)) return false;
					}
				}

				// Usage limit
				if (isset($couponDetails['usage_count']) && $couponDetails['usage_count']>=$couponDetails['usage_limit'] && $couponDetails['usage_limit']>0 && $couponDetails['usage_limit']!='') {
					return false;
				}
				// Exp date
				else if ($couponDetails['expiry_date']<current_time( 'timestamp' ) && $couponDetails['expiry_date']!='') {
					return false;
				}
				// If NOT in included products = fail
				else if (!empty($couponDetails['product_ids']) && !in_array($data['id'], $couponDetails['product_ids']) ) {
					return false;
				}
				// If IN excluded products = fail
				else if (!empty($couponDetails['exclude_product_ids']) && in_array($data['id'], $couponDetails['exclude_product_ids'])) {
					return false;
				}
				else {
					return true;
				}

			}

			if (validateCoupon()===true) {


				if ($couponDetails['discount_type']=='percent_product') {
					$totalNoShipping = $price+$mountingPrice+($pricePerFigure*$totalFigures);
					$discount = ($totalNoShipping/100)*$couponDetails['coupon_amount'];
				}
				else {
					$discount = $couponDetails['coupon_amount'];
				}
				if ($couponDetails['free_shipping']=='yes') {
					$shipping = 0;
				}


				// assign coupon to order
				$order->add_coupon(sanitize_text_field($data['coupon']), $discount);

				// increase usage count for coupon
				$coupon = new WC_Coupon($data['coupon']);
				$coupon->inc_usage_count();
			}
		}
	}



	// Calculate the order total
	$total = ($price+$mountingPrice+($pricePerFigure*$totalFigures))-$discount;
	if ($total<0) {
		$total = 0;
	}

	$total += $shipping;

	// round total to two decimal places
	$total = round($total, 2);


	// Add the discount
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_discount', '".$discount."')
	";
	$result = mysql_query($sql);


	// Add the mounting
	$sql = "
		INSERT INTO wp_woocommerce_order_items(order_item_name, order_item_type, order_id)
		VALUES('Mounting (".ucfirst($data['mounting']['type'])." - ".str_replace('x', ' x ', $data['mounting']['size']).")', 'fee', ".$order->id.")
	";
	$result = mysql_query($sql);
	$orderItemId = mysql_insert_id();
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_total', '".$mountingPrice."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_subtotal', '".$mountingPrice."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_tax', '0')
	";
	$result = mysql_query($sql);


	// Add the figures
	$sql = "
		INSERT INTO wp_woocommerce_order_items(order_item_name, order_item_type, order_id)
		VALUES('Figures (".$totalFigures.")', 'fee', ".$order->id.")
	";
	$result = mysql_query($sql);
	$orderItemId = mysql_insert_id();
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_total', '".($pricePerFigure*$totalFigures)."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_subtotal', '".($pricePerFigure*$totalFigures)."')
	";
	$result = mysql_query($sql);
	$sql = "
		INSERT INTO  wp_woocommerce_order_itemmeta(order_item_id, meta_key, meta_value)
		VALUES(".$orderItemId.", '_line_tax', '')
	";
	$result = mysql_query($sql);


	// Add the shipping
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_shipping', '".$shipping."')
	";
	$result = mysql_query($sql);


	// Add the total
	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_total', '".$total."')
	";
	$result = mysql_query($sql);

	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_tax', 0)
	";
	$result = mysql_query($sql);

	$sql = "
		INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
		VALUES(".$order->id.", '_order_shipping_tax', 0)
	";
	$result = mysql_query($sql);



	// Add Image Details
	$imageDetails = '';

	$i = 1;
	foreach($data['figurePortraitDetails'] as $key=>$value) {
		$imageDetails .= 'Image '.$i.' -
Name: '.$data['uploadedImages'][$key]['name'].'
Link: '.$data['uploadedImages'][$key]['url'].'
--------------------------------------------------------------------------
';
		$i++;

		$z = 1;
		foreach($data['figurePortraitDetails'][$key] as $key2=>$value2) {
			$imageDetails .= 'Figure '.$z.' -
';
			$z++;

			foreach($data['figurePortraitDetails'][$key][$key2] as $key3=>$value3) {
		$imageDetails .= $key3.":
".$value3."

";
			}
		}

		$imageDetails .= '
';
	}

	if ($imageDetails!='') {
		$sql = "
			INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
			VALUES(".$order->id.", 'Image Details', '".$imageDetails."')
		";
		$result = mysql_query($sql);
	}



	// Add the General Portrait Details
	$generalPortraitDetails = '';

	foreach($data['generalPortraitFields'] as $key=>$value) {
		$generalPortraitDetails .= $key.":
".$value."

";
	}

	if ($generalPortraitDetails!='') {
		$sql = "
			INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
			VALUES(".$order->id.", 'General Portrait Details', '".$generalPortraitDetails."')
		";
		$result = mysql_query($sql);
	}


	// Output the required stuff for Paypal
	echo $order->id.'|-|-|'.$total.'|-|-|'.md5('ak970'.$total.$order->id.'b709u');
?>