<?php
// Log errors to ipn_errors.log in this directory
ini_set('log_errors', true);
ini_set('error_log', dirname(__FILE__).'/ipn_errors.log');

// debug
// ob_start();
// echo date('d.m.Y H:i:s');
// print_r($_SERVER);
// print_r($_POST);
// print_r($_GET);
// $debug = ob_get_clean();
// $file = '1debug-ipn.txt';
// file_put_contents($file, $debug);

// load WordPress
require_once(dirname(__FILE__)."/../../../../wp-load.php");
require_once(dirname(__FILE__)."/../../../plugins/woocommerce/woocommerce.php");
require_once(dirname(__FILE__)."/../../../plugins/woocommerce/includes/class-wc-emails.php");

// Intantiate the IPN listener
include('ipnlistener.php');
$listener = new IpnListener();

// Tell the IPN listener to use the PayPal test sandbox if activated
$paypalSettings = get_option('woocommerce_paypal_settings');
if($paypalSettings['testmode'] == 'yes') {
	$listener->use_sandbox = true;
}

// Try to process the IPN POST
try {
	$listener->requirePostMethod();
	$verified = $listener->processIpn();

// debug
// ob_start();
// echo date('d.m.Y H:i:s');
// var_dump($verified);
// print_r($_SERVER);
// print_r($_POST);
// print_r($_GET);
// $debug = ob_get_clean();
// $file = '3debug-verified.txt';
// file_put_contents($file, $debug);



} catch (Exception $e) {
	error_log($e->getMessage());
	exit();
}

if ($verified) {

	// Get out the custom data
	$custom_data = explode('|-|-|', $_POST['custom']);
	$_POST['order_id'] = $custom_data[0];
	$_POST['amount'] = $custom_data[1];
	$_POST['epic_key'] = $custom_data[2];

	// Make sure the payment status is "Completed"
	if ($_POST['payment_status'] != 'Completed') {
		exit();
	}


// debug
// ob_start();
// echo date('d.m.Y H:i:s');
// echo md5('ak970'.$_POST['amount'].$_POST['order_id'].'b709u');
// print_r($_SERVER);
// print_r($_POST);
// print_r($_GET);
// $debug = ob_get_clean();
// $file = '4debug-key.txt';
// file_put_contents($file, $debug);

	// Ensure the epicKey is correct
	if ($_POST['epic_key'] != md5('ak970'.$_POST['amount'].$_POST['order_id'].'b709u')) {
		exit();
	}

	// If the script is still running here, it's valid - so update the order
	$order = new WC_Order($_POST['order_id']);
	$order->update_status('processing');
}
?>