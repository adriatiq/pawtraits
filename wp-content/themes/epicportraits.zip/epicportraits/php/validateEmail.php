<?php
	list($user, $domain) = explode('@', $_POST['email']);
	if (checkdnsrr($domain, 'MX')) {
		echo "VALID";
	}
	else {
		echo "INVALID";
	}
?>