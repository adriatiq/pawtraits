<?php
	// Header
	include 'includes/headStyles.php';




	echo "
		<link rel='stylesheet' href='".$themePath."css/index.css'>
		<script type='text/javascript' src='".$themePath."js/index.js'></script>
	";





	// If there's an error, show the modal
	if (isset($_GET['error']) && $_GET['error']=='portraitDoesNotExist') {
		echo "
			<script type='text/javascript'>
				$(document).ready(function() {
					showModal('<div class=\"errorModal\"><span>Sorry, this portrait does not exist.</span><a href=\"javascript: hideModal(); scrollTo(\\'designsPanel\\');\" class=\\'button\\'>Browse portrait desgins</a></div>', 'regular');
				});
			</script>
		";
	}





	global $wpdb;
	// Get the products
	$sql = "
		SELECT *
		FROM  `wp_posts`
		WHERE `post_type` =  'product'
		AND `post_status` = 'publish'
	";
	//$result = mysql_query($sql);
	$result = $wpdb->get_results($sql);


	// Get the categories (in use only)
	$all_cats = get_terms('product_cat');


	$categories = '';
	foreach ($all_cats as $key => $value) {
		$categories .= "'".$all_cats[$key]->slug."',";
	}
	if ($categories!='') {
		$categories = substr($categories, 0, strlen($categories)-1);
	}


	// Output the products
	echo "
		<script type='text/javascript'>
			// Setup some dummy gallery items
			var galleryItem = [];
			var categories = [".$categories."];
	";


	//for ($i=0; $i<mysql_num_rows($result); $i++) {
	$i = 0;
	foreach ( $result as $result_d ) {
		//$id = mysql_result($result, $i, 'ID');
		$id = $result_d->ID;
		//$title = mysql_result($result, $i, 'post_title');
		$title = $result_d->post_title;
		//$post_name = mysql_result($result, $i, 'post_name');
		$post_name = $result_d->post_name;


		// Get the custom field data
		$data = get_post_meta($id);

		if (isset($data['maximum_figures'][0])) { $max_figures = $data['maximum_figures'][0]; } else { $max_figures = 0; }
		if (isset($data['minimum_figures'][0])) { $min_figures = $data['minimum_figures'][0]; } else { $min_figures = 1; }
		if (isset($data['photo_requirements'][0])) { $requirements = $data['photo_requirements'][0]; } else { $requirements = ''; }



		// Setup figures text
		if ($min_figures==$max_figures) {
			if ($min_figures==1) {
				$figures_text = $min_figures.' Person Only';
			}
			else {
				$figures_text = $min_figures.' People Only';
			}
		}
		else if ($min_figures!=0 && $max_figures==0) {
			if ($min_figures==1) {
				$figures_text = 'Minimum '.$min_figures.' Person';
			}
			else {
				$figures_text = 'Minimum '.$min_figures.' People';
			}
		}
		else if ($max_figures!=0 && $min_figures!=0) {
			$figures_text = $min_figures.' to '.$max_figures.' People';
		}



		// Get categories
		$cat_arr = wp_get_post_terms($id, 'product_cat');
		$categories = '';
		for ($z=0; $z<count($cat_arr); $z++) {
			$categories .= $cat_arr[$z]->slug.',';
		}
		if ($categories!='') {
			$categories = substr($categories, 0, strlen($categories)-1);
		}



		$image = get_the_post_thumbnail($id, 'medium');
		if ($image!==false) {
			$image_url = (preg_match('~\bsrc="([^"]++)"~', $image, $matches)) ? $matches[1] : '';
			$width = (preg_match('~\bwidth="([^"]++)"~', $image, $matches)) ? $matches[1] : '';
			$height = (preg_match('~\bheight="([^"]++)"~', $image, $matches)) ? $matches[1] : '';

			echo "
				galleryItem[".$i."] = [];
				galleryItem[".$i."]['id'] = ".$id.";
				galleryItem[".$i."]['post_name'] = '".$post_name."';
				galleryItem[".$i."]['image'] = '".$image_url."';
				galleryItem[".$i."]['width'] = ".$width.";
				galleryItem[".$i."]['height'] = ".$height.";
				galleryItem[".$i."]['title'] = '".addslashes($title)."';
				galleryItem[".$i."]['figures'] = '".$figures_text."';
				galleryItem[".$i."]['requirements'] = '".addslashes($requirements)."';
				galleryItem[".$i."]['category'] = '".$categories."';
			";
		}
		$i++;
	}
	echo "</script>"
?>
	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper'>



			<?php
				include 'includes/topMenu.php';
			?>




			<!---------- BANNER PANEL ---------->

			<section class='bannerPanel'>
				<div class='bannerContent'>
					<?php
						layerslider(1);
					?>
				</div> <!-- .bannerContent -->
				<div class='overlay'>
					<?php
						if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'webkit')!==false) {
							echo "<img src='".$themePath."images/bannerLogo.png' alt='' class='bannerLogo' />";
						}
						else {
							echo "
								<img src='".$themePath."images/bannerLogoBW.png' alt='' class='bannerLogo' />
								<style type='text/css'>
									.browseButton:hover, .topBrowseButton:hover {
										color: #555555 !important;
									}
								</style>
							";
						}
					?>

					<div class='bannerBlurb'>
						<?php
							echo get_field('homepage_blurb', '10');
						?>

						<a href="javascript: scrollTo('designsPanel');" class='browseButton'>Start by browsing portrait designs</a>
					</div> <!-- .bannerBlurb -->

				</div> <!-- .overlay -->
			</section> <!-- .bannerPanel -->
			<div class="the_blurb">
				<?php
					echo get_field('homepage_blurb_mobile', '10');
				?>
				<a href="javascript: scrollTo('designsPanel');" class="browseButtonMobile">Browse portrait designs</a>
			</div>



			<?php
				include 'includes/nav.php';
			?>




			<!---------- DESIGNS PANEL ---------->
			<section class='designsPanel' id='designs' rel='addNavPadding'>
				<div class='designsContent'></div>
				<div class='loadingMessage'><div class='text'>Loading...</div></div>
			</section> <!-- .designsPanel -->




		</div> <!-- .contentWrapper -->


		<?php // lightbox activate portrait image if page loaded with ?epic=XXX param
		if(isset($_GET['epic']) && $_GET['epic'] && is_numeric($_GET['epic']) && $_GET['epic'] > 0):
			$processed_img = getOrderCompletedImageUrl($_GET['epic']);
			?>

			<script type="text/javascript">
				$(function() {
					setTimeout(function() {
						showModal('<img src="<?php echo $processed_img; ?>" alt="" />', 'finishedPortrait');
					}, 100);
				});
			</script>

		<?php endif; ?>



		<?php
			// Footer
			include 'includes/footer.php';
		?>

	</body>
</html>