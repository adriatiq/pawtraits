<?php
// declare Woocommerce support
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

// replace WP logo on admin login
add_action( 'login_head', 'my_login_logo' );
function my_login_logo() {
    $logo_url = get_template_directory_uri() . '/images/logo.png';
    echo "
	<style>
	body.login #login h1::before {
		content: '';
		display: block;
		margin: 0 auto;
		background: url('" . $logo_url . "') no-repeat center top transparent !important;
		height: 56px;
		width: 138px;
		margin-bottom: 12px;
	}
	body.login #login h1 a {
		display: none;
	}
	</style>
	";
}

// remove woocommerce hook adjusting lost password url
remove_filter( 'lostpassword_url',  'wc_lostpassword_url', 10, 0 );


// ajax function validating coupon code
add_action( 'wp_ajax_validate_coupon', 'my_validate_coupon' );
add_action( 'wp_ajax_nopriv_validate_coupon', 'my_validate_coupon' );

function my_validate_coupon() {
	$coupon_code = $_POST['code'];
	$res = my_load_coupon($coupon_code);

	// show result
	echo json_encode($res);
	exit;
}


function my_load_coupon($coupon_code) {
	// try load coupon and check if it exists
	$coupon = new WC_Coupon($coupon_code);
	if(is_null($coupon->id)) {
		$res = array('status' => false);

	} else {
		// coupon exists, return its data
		$res = array(
			'status' => true,
			'coupon' => array(
				'free_shipping' => $coupon->free_shipping,
				'discount_type' => $coupon->discount_type,
				'coupon_amount' => $coupon->coupon_amount,
				'expiry_date' => $coupon->expiry_date,
				'usage_count' => $coupon->usage_count,
				'usage_limit' => $coupon->usage_limit,
				'exclude_sale_items' => $coupon->exclude_sale_items,
				'product_categories' => $coupon->product_categories,
				'exclude_product_categories' => $coupon->exclude_product_categories,
				'product_ids' => $coupon->product_ids,
				'exclude_product_ids' => $coupon->exclude_product_ids,
			),
		);
	}

	return $res;
}


// fix WP Layer slider initilization
add_filter('layerslider_post_parse_defaults', 'my_layerslider_post_parse_defaults');
function my_layerslider_post_parse_defaults($slides) {

	// remove multislashes for $slides['properties']['attrs']['cbInit']
	if(isset($slides['properties']['attrs']['cbInit']) && strpos($slides['properties']['attrs']['cbInit'], "\\") !== false ) {
		$val = $slides['properties']['attrs']['cbInit'];

		// remove multiple slashes
		$val = preg_replace("~\\\\+'~i", "'", $val);

		// replace val
		$slides['properties']['attrs']['cbInit'] = $val;
	}

	return $slides;
}

// register ACF settings page
if( function_exists('acf_add_options_page') ) {
	acf_add_options_page(array(
		'page_title' 	=> 'Epic Portraits Settings',
		'menu_title'	=> 'Epic Portraits Settings',
		'menu_slug' 	=> 'ep-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
}

/* ----------- ORIGINAL FUNCTIONS ---------------- */

	if ( !defined('ABSPATH') ) {
    define('ABSPATH', dirname(__FILE__) . '/');
	}

	define('CONCATENATE_SCRIPTS', false);

	// Add a Photo Instructions Image to products
	if (class_exists('MultiPostThumbnails')) {
		new MultiPostThumbnails(
			array(
				'label' => 'Photo Instructions Image',
				'id' => 'instructions-image',
				'post_type' => 'product'
			)
		);
	}


	// Add new WooCommerce Mounting Settings
	class WC_Settings_Tab_Mounting {

			/**
			 * Bootstraps the class and hooks required actions & filters.
			 *
			 */
			public static function init() {
					add_filter('woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50);
					add_action('woocommerce_settings_tabs_settings_tab_mounting', __CLASS__ . '::settings_tab');
					add_action('woocommerce_update_options_settings_tab_mounting', __CLASS__ . '::update_settings');
			}


			/**
			 * Add a new settings tab to the WooCommerce settings tabs array.
			 *
			 * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
			 * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
			 */
			public static function add_settings_tab( $settings_tabs ) {
					$settings_tabs['settings_tab_mounting'] = __('Mounting Configuration', 'woocommerce-mounting-settings');
					return $settings_tabs;
			}


			/**
			 * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
			 *
			 * @uses woocommerce_admin_fields()
			 * @uses self::get_settings()
			 */
			public static function settings_tab() {
					woocommerce_admin_fields( self::get_settings() );
			}


			/**
			 * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
			 *
			 * @uses woocommerce_update_options()
			 * @uses self::get_settings()
			 */
			public static function update_settings() {
					woocommerce_update_options( self::get_settings() );
			}


			/**
			 * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
			 *
			 * @return array Array of settings for @see woocommerce_admin_fields() function.
			 */
			public static function get_settings() {

					$settings = array(
							'section_title' => array(
									'name'     => __('Mounting Configuration', 'woocommerce-mounting-settings'),
									'type'     => 'title',
									'desc'     => 'Enter one mounting size per line in the following format: <strong>widthxheight|price|postage cost</strong><br /><br />Example: <strong>500x1000|20.50|5.25</strong>',
									'id'       => 'wc_settings_tab_mounting_section_title'
							),
							'paper' => array(
									'name' => __('Paper', 'woocommerce-mounting-settings'),
									'type' => 'textarea',
									'desc' => __( '', 'woocommerce-mounting-settings'),
									'id'   => 'wc_settings_tab_mounting_paper'
							),
							'canvas' => array(
									'name' => __('Canvas', 'woocommerce-mounting-settings'),
									'type' => 'textarea',
									'desc' => __( '', 'woocommerce-mounting-settings'),
									'id'   => 'wc_settings_tab_mounting_canvas'
							),
							'acrylic' => array(
									'name' => __('Acrylic', 'woocommerce-mounting-settings'),
									'type' => 'textarea',
									'desc' => __( '', 'woocommerce-mounting-settings'),
									'id'   => 'wc_settings_tab_mounting_acrylic'
							),

							'section_end' => array(
									 'type' => 'sectionend',
									 'id' => 'wc_settings_tab_mounting_section_end'
							)
					);

					return apply_filters( 'wc_settings_tab_mounting_settings', $settings );
			}

	}

	WC_Settings_Tab_Mounting::init();




	// Add new WooCommerce Shippinf Settings
	class WC_Settings_Tab_Shipping {

			/**
			 * Bootstraps the class and hooks required actions & filters.
			 *
			 */
			public static function init() {
					add_filter('woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50);
					add_action('woocommerce_settings_tabs_settings_tab_shipping', __CLASS__ . '::settings_tab');
					add_action('woocommerce_update_options_settings_tab_shipping', __CLASS__ . '::update_settings');
			}


			/**
			 * Add a new settings tab to the WooCommerce settings tabs array.
			 *
			 * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
			 * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
			 */
			public static function add_settings_tab( $settings_tabs ) {
					$settings_tabs['settings_tab_shipping'] = __('Shipping', 'woocommerce-shipping-settings');
					return $settings_tabs;
			}


			/**
			 * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
			 *
			 * @uses woocommerce_admin_fields()
			 * @uses self::get_settings()
			 */
			public static function settings_tab() {
					woocommerce_admin_fields( self::get_settings() );
			}


			/**
			 * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
			 *
			 * @uses woocommerce_update_options()
			 * @uses self::get_settings()
			 */
			public static function update_settings() {
					woocommerce_update_options( self::get_settings() );
			}


			/**
			 * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
			 *
			 * @return array Array of settings for @see woocommerce_admin_fields() function.
			 */
			public static function get_settings() {

					$settings = array(
							'section_title' => array(
									'name'     => __('Shipping', 'woocommerce-shipping-settings'),
									'type'     => 'title',
									'desc'     => '',
									'id'       => 'wc_settings_tab_shipping_section_title'
							),

							'local_delivery' => array(
									'name' => __('Australia Wide Delivery ($)', 'woocommerce-shipping-settings'),
									'type' => 'text',
									'desc' => __( '', 'woocommerce-shipping-settings'),
									'id'   => 'wc_settings_tab_shipping_local'
							),
							'international_delivery' => array(
									'name' => __('International Delivery ($)', 'woocommerce-shipping-settings'),
									'type' => 'text',
									'desc' => __( '', 'woocommerce-shipping-settings'),
									'id'   => 'wc_settings_tab_shipping_international'
							),

							'section_end' => array(
									 'type' => 'sectionend',
									 'id' => 'wc_settings_tab_shipping_section_end'
							)
					);

					return apply_filters( 'wc_settings_tab_shipping_settings', $settings );
			}

	}

	WC_Settings_Tab_Shipping::init();


	add_theme_support('menus');

	add_theme_support('post-thumbnails');
	add_image_size('email', 270, 99999);






	function wpb_mce_buttons_2($buttons) {
		array_unshift($buttons, 'styleselect');
		return $buttons;
	}
	add_filter('mce_buttons_2', 'wpb_mce_buttons_2');



	/*
	* Callback function to filter the MCE settings
	*/

	function my_mce_before_init_insert_formats( $init_array ) {

	// Define the style_formats array

		$style_formats = array(
			// Each array child is a format with it's own settings
			array(
				'title' => 'Regular Button',
				'block' => 'span',
				'classes' => 'button',
				'wrapper' => true,

			),
			array(
				'title' => 'Big Button',
				'block' => 'span',
				'classes' => 'bigButton',
				'wrapper' => true,
			),
		);
		// Insert the array, JSON ENCODED, into 'style_formats'
		$init_array['style_formats'] = json_encode( $style_formats );

		return $init_array;

	}
	// Attach callback to 'tiny_mce_before_init'
	add_filter( 'tiny_mce_before_init', 'my_mce_before_init_insert_formats' );


/* --- VARIOUS UTILITIES --- */

// returns img uploaded for finished order
function getOrderCompletedImageUrl($orderID) {
	$order = new WC_Order( $orderID );
	if($order) {
		// get image
		$imageID = get_post_meta($orderID, 'completed_image', true);
		if($imageID) {
			$src = wp_get_attachment_image_src( $imageID, 'full' );
			if($src && isset($src[0])) return $src[0];
		}
	}
}

// returns url with lightbox showing finished image
function getOrderCompletedShareUrl($orderID) {
	return site_url('?epic=' . $orderID);
}