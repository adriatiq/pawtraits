<?php
	// Header
	include 'includes/headStyles.php';
?>
	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper regularPage'>




			<?php
				include 'includes/topMenu.php';
				include 'includes/pageNav.php';
			?>




			<!---------- CONTENT PANEL ---------->

			<section class='contentPanel' rel='addNavPadding'>

				<?php
					// Start the wordpress loop
					if (have_posts()) : while (have_posts()) : the_post();

						// Print out the title
						echo "<h1>".trim(wp_title('', false))."</h1>";

						// Print out the content
						the_content();

					endwhile; endif;
				?>

				<?php include 'includes/copyright.php'; ?>

			</section> <!-- .contentPanel -->

		</div> <!-- .contentWrapper -->


		<?php
			// Footer
			include 'includes/footer.php';
		?>

	</body>
</html>