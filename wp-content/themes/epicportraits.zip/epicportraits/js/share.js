// Facebook
// -------------------------------------------------------------------
window.fbAsyncInit = function() {
  FB.init({
    appId      : '867661303303938',
    xfbml      : true,
    version    : 'v2.2'
  });
};

(function(d, s, id){
   var js, fjs = d.getElementsByTagName(s)[0];
   if (d.getElementById(id)) {return;}
   js = d.createElement(s); js.id = id;
   js.src = "//connect.facebook.net/en_US/sdk.js";
   fjs.parentNode.insertBefore(js, fjs);
 }(document, 'script', 'facebook-jssdk'));



function shareOnFacebook(orderID, key, coupon, name, description, image, url, caption) {

	// login to FB application
	FB.init({
		appId      : '1518619561738425',
		xfbml      : true,
		version    : 'v2.2'
	});

	/*
	// - debug -
    FB.getLoginStatus(function(response){
        runFbInitCriticalCode();
    });
	*/


	FB.ui({
		method: 'feed',
		name: name,
		link: url,
		picture: image,
		caption: caption,
		description: description
	}, function(response) {
		if (typeof response === 'object' && typeof response != 'undefined' && response) {
			$('.facebookButton').addClass('loading');
			$('.facebookButton').attr('href', "javascript:;");
			$('.facebookButton').html("<img src='"+themePath+"images/facebookLoading.gif' alt='Loading' />");

			$.ajax({
				type: "POST",
				async: false,
				url: themePath+"php/enableCoupon.php",
				data: "id="+orderID+"&key="+key+"&coupon="+coupon,
				success: function(msg) {
					$('.facebookContainer').fadeOut(400, function() { $('.facebookContainer').html("<h3 class='successMessage'>Shared on Facebook! We have emailed you your coupon code.</h3>"); $('.facebookContainer').fadeIn(400); })
				}
			});

		}
	});
}




// Twitter
// -------------------------------------------------------------------

function shareOnTwitter() {
	$('.hiddenTwitterButton iframe #widget a').click();
}

function twitterSuccess() {
	$.ajax({
		type: "POST",
		async: false,
		url: themePath+"php/enableCoupon.php",
		data: "id="+global_orderID+"&key="+global_key+"&coupon="+global_couponCode,
		success: function(msg) {
			$('.twitterContainer').fadeOut(400, function() { $('.twitterContainer').html("<h3 class='successMessage'>Shared on Twitter! We have emailed you your coupon code.</h3>"); $('.twitterContainer').fadeIn(400); })
		}
	});
}