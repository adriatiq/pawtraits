function isScrolledIntoView(elem) {
	var docViewTop = $(window).scrollTop();
	var docViewBottom = docViewTop + $(window).height();
	
	var elemTop = $(elem).offset().top;
	var elemBottom = elemTop+(($(elem).height()/4)*3);
	
	return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

function showTipsTricks() {
	$(".contentPanel .tipTrickContainer").each(function() {
		if (isScrolledIntoView($(this))) {
			$(this).addClass('inView');
		}
	});
}

$(window).scroll(function() {
	showTipsTricks();
});

$(window).load(function() {
	$('#inViewStart').addClass('inView');
	showTipsTricks();

	$("img.lazy").lazyload({
		threshold: 800,
		effect: "fadeIn"
	});
});