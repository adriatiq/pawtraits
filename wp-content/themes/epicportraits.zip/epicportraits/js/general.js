/* GENERAL
------------------------------------------------------- */
// Ensure we can use the $ for jQuery in Wordpress
var $ = jQuery.noConflict();


// detect IE
function msieversion() {

        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");

        if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer, return version number
            return (parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
        else                 // If another browser, return 0
           return false;

   return false;
}

// handle all browsers
$(function() {
	if(msieversion()) {
		// class for body
		if(msieversion() < 11) {
			$('body').addClass('ie10orWorse');
		}

		// show warning popup for IE9 or worse
		if(msieversion() < 10) {
			setTimeout(function() {
				showModal("<div class='textModalInner browserWarningModal'><h2 class='title'>Outdated Browser Warning</h2><p>Oh snap! Looks like you need to update your browser to use our file drop feature.<br />Try updating to the latest version of your browser.</p><p>PS. We recommend using <a target='_blank' href='http://www.google.com/chrome/'>Google Chrome</a>.</div>", 'textModal');
			}, 1000);
		}
	}

	// bind waiting message functionality
	$('#waiting-message .close').click(function() {
		$('#waiting-message').hide();
	});
	/*
	if($('#waiting-message').length) {
		if(!readCookie('waiting_message_hidden')) {
			$('#waiting-message').show();
		}

		// bind closing function
		$('#waiting-message .close').click(function() {
			$('#waiting-message').hide();
			createCookie('waiting_message_hidden', '1', 7);
		});
	}
	*/
});


/* COOKIES
------------------------------------------------------- */
function createCookie(name,value,days) {
	var expires = "";
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		expires = "; expires="+date.toGMTString();
	}
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}


/* FIXED NAVIGATION
------------------------------------------------------- */
function swapHeader() {
	// Ensure the designsPanel and nav have the correct margins and such
	$('.navPanel').css('height', 'auto');
	var navHeight = $('.navPanel').outerHeight();

	$('.navPanel').css('height', navHeight+'px');
	$('.navPanel').css('margin-bottom', '-'+navHeight+'px');
	$('[rel="addNavPadding"],[rel="addNavNegativeMargin"]').css('padding-top', navHeight+'px');
	$('[rel="addNavNegativeMargin"]').css('margin-top', '-'+navHeight+'px');


	// Work out if the nav should be fixed or not
	var scrollTop = $(window).scrollTop();
	var offsetFixed = $('.bannerPanel').outerHeight();
	var offsetWhite = $('.bannerPanel').outerHeight() - 50;
	// append blurb to offset if it is visible
	if($('.bannerPanel + .the_blurb').is(':visible')) offsetFixed += $('.bannerPanel + .the_blurb').outerHeight();

	if (scrollTop >= offsetFixed) {
		$('.navPanel').addClass('fixedNav');
	}
	else {
		$('.navPanel').removeClass('fixedNav');
	}

	// separate class for when right menu icons enters white background
	if (scrollTop >= offsetWhite) {
		$('.navPanel').addClass('darkenMenuIco');
	}
	else {
		$('.navPanel').removeClass('darkenMenuIco');
	}
}




/* MODAL
------------------------------------------------------- */
function showModal(content, type) {
	$('body').css('overflow', 'hidden');

	// clear classes
	$('.modal').removeClass('textModal photoModal finishedModal');

	// assign classes by new type
	if (type=='photoInstructions') {
		$('.modal').addClass('textModal photoModal');
	}
	else if (type=='finishedPortrait') {
		$('.modal').addClass('finishedModal');
	}
	else {
		$('.modal').addClass('textModal');
	}

	if (content!='special') {
		$('.modal .modalContent').html(content);
	}
	else {
		$('.modal .modalContent').html("<img src='"+themePath+"images/ferrisBueller.gif' alt='' />");
	}
	$('.modal').fadeIn(200);

	$('.modal').scroll(function() {
		$('.modalBackground').css('top', $('.modal').scrollTop()+'px')
	});
}

function hideModal() {
	$('body').css('overflow', 'auto');
	$('.modal').fadeOut(200, function() { $('.modal .modalContent').html(''); });

	$('.modalBackground').css('top', '0');
	$('.modal').unbind('scroll');
}



function nl2br(str, is_xhtml) {
  var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
  return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
}

function submitPortraitIdea() {
	// Validate
	var name = $(".portraitIdeaModal input[name='name']").val();
	var email = $(".portraitIdeaModal input[name='email']").val();
	var portraitIdea = $(".portraitIdeaModal textarea[name='portraitIdea']").val();



	// Validate email
	var validEmail = true;
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if (!re.test(email)) {
		validEmail = false;
	}
	else {
		$.ajax({
			type: "POST",
			async: false,
			url: themePath+"php/validateEmail.php",
			data: "email="+email,
			success: function(msg) {
				if (msg!='VALID') {
					validEmail = false;
				}
			}
		});
	}




	var valid = true;
	if (name=='') {
		$(".portraitIdeaModal input[name='name']").addClass('error');
		valid = false;
	}
	else {
		$(".portraitIdeaModal input[name='name']").removeClass('error');
	}

	if (email=='' || validEmail===false) {
		$(".portraitIdeaModal input[name='email']").addClass('error');
		valid = false;
	}
	else {
		$(".portraitIdeaModal input[name='email']").removeClass('error');
	}

	if (portraitIdea=='') {
		$(".portraitIdeaModal textarea[name='portraitIdea']").addClass('error');
		valid = false;
	}
	else {
		$(".portraitIdeaModal textarea[name='portraitIdea']").removeClass('error');
	}


	// If it's valid
	if (valid===true) {
		// Disable fields
		$(".portraitIdeaModal input, .portraitIdeaModal textarea").prop('disabled', true);

		// Swap button to loading state
		$(".portraitIdeaModal a").addClass('loading');
		$(".portraitIdeaModal a").html('');
		$(".portraitIdeaModal a").attr('href', 'javascript:;');

		// Send email with ajax
		$.ajax({
			type: "POST",
			async: false,
			url: themePath+"php/sendPortraitIdeaEmail.php",
			data: { 'email': email, 'name': name, 'portraitIdea': nl2br(portraitIdea, true)  },
			success: function(msg) {
				// Swap to completed state
				$(".portraitIdeaModal").fadeOut(400, function() {
					$(".portraitIdeaModal").html("<h2 class='title'>Your idea has been submitted!</h2><div style='float: left; padding-bottom: 1em;'>Thanks for the input. We will get back to you shortly.</div><div class='clear'></div><a href='javascript: hideModal();' class='submitButton'>Close</a>");
					$(".portraitIdeaModal").fadeIn(400);
				});
			}
		});


	}
}




/* SIDE MENU
------------------------------------------------------- */
var menuShowing = false;
function showMenu() {
	$('.sideMenu,.contentWrapper,nav,.menuButton,.nextButton').addClass('menuShowing');
	$('.menuButton').attr('href', 'javascript:;');
	$('.contentWrapper').attr('onclick', 'hideMenu();');
	menuShowing = true;
}

function hideMenu() {
	$('.sideMenu,.contentWrapper,nav,.menuButton,.nextButton').removeClass('menuShowing');
	setTimeout(function() { $('.menuButton').attr('href', 'javascript: showMenu();'); $('.contentWrapper').attr('onclick', ''); menuShowing = false; }, 400);
}

function setCurrentMenu(button) {
	// If we're specifically telling it to set "current" on a button
	if (typeof button != 'undefined') {
		$('.sideMenu .current-menu-item').removeClass('current-menu-item');
		$('.sideMenu .'+button).parent().addClass('current-menu-item');
	}
	// Otherwise, work out the current item from the scroll position
	else {
		if ($('.homeButton').parent().hasClass('current-menu-item') || $('.designsButton').parent().hasClass('current-menu-item')) {
			var sections = setupSections();
			var scrollTop = $(window).scrollTop();

			$('.sideMenu .current-menu-item').removeClass('current-menu-item');

			// Only do this bit for the homepage
			if (typeof sections['designsPanel'] != 'undefined') {
				if (scrollTop<sections['designsPanel']) {
					$('.sideMenu .homeButton').parent().addClass('current-menu-item');
				}
				else if (scrollTop>=sections['designsPanel']) {
					$('.sideMenu .designsButton').parent().addClass('current-menu-item');
				}
			}
		}
	}
}

// If they press Esc, hide the menu and modal
$(document).keyup(function(e) {
  if (e.keyCode == 27) {
		hideMenu();
		hideModal();
	}
});




/* SCROLL NAVIGATION
------------------------------------------------------- */
function scrollTo(panel) {
	// If the menu's showing, hide the menu - then do the scroll
	if (menuShowing===true) {
		hideMenu();
		setTimeout(function() { doScroll(panel); }, 400);
	}
	// Otherwise just do the scroll
	else {
		doScroll(panel);
	}
}

function doScroll(panel) {
	var sections = setupSections();
	var scrollTop = $(window).scrollTop();
	if (scrollTop!=sections[panel]) {
		disableScroll();
		$('html, body').animate( { scrollTop: sections[panel] }, 750, 'easeOutQuad', function() {enableScroll();});
	}
}

function setupSections() {
	var sections = {};
	$("section").each(function() {
		var tmp = $(this).attr('class');
		sections[tmp] = $(this).offset().top;
	});
	return sections;
}




/* ENABLE / DISABLE SCROLLING
------------------------------------------------------- */
function preventDefault(e) {
	e = e || window.event;
	if (e.preventDefault) {
		e.preventDefault();
	}
	e.returnValue = false;
}

function keydown(e) {
	var keys = [37, 38, 39, 40, 32, 33, 34, 35, 36];

	for (var i = keys.length; i--;) {
		if (e.keyCode === keys[i]) {
			preventDefault(e);
			return;
		}
	}
}

function wheel(e) {
	preventDefault(e);
}

function disableScroll() {
	if (window.addEventListener) {
		window.addEventListener('DOMMouseScroll', wheel, false);
	}
	window.onmousewheel = document.onmousewheel = wheel;
	document.onkeydown = keydown;
}

function enableScroll() {
	if (window.removeEventListener) {
		window.removeEventListener('DOMMouseScroll', wheel, false);
	}
	window.onmousewheel = document.onmousewheel = document.onkeydown = null;
}




/* TRIGGERS
------------------------------------------------------- */
$(document).ready(function() {
	$(window).scroll(function() {
		swapHeader();
		setCurrentMenu();
	});
	$(window).resize(function() {
		swapHeader();
	});
	swapHeader();
	setCurrentMenu();

	// Add a class to the document of "touchDevice" if it's a touch device
	if (("ontouchstart" in document.documentElement)) {
		document.documentElement.className += "touchDevice";
	}

});