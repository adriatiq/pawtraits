// extend Date by toISOtype for old IE
if ( !Date.prototype.toISOString ) {
    (function() {
        function pad(number) {
            var r = String(number);
            if ( r.length === 1 ) {
                r = '0' + r;
            }
            return r;
        }
        Date.prototype.toISOString = function() {
            return this.getUTCFullYear()
                + '-' + pad( this.getUTCMonth() + 1 )
                + '-' + pad( this.getUTCDate() )
                + 'T' + pad( this.getUTCHours() )
                + ':' + pad( this.getUTCMinutes() )
                + ':' + pad( this.getUTCSeconds() )
                + '.' + String( (this.getUTCMilliseconds()/1000).toFixed(3) ).slice( 2, 5 )
                + 'Z';
        };
    }() );
}

/* VALIDATION
------------------------------------------------------- */
function enablePanel(panel) {
	validatePanel(panel);
}



// NOTE: The panel passed in here is always the NEXT panel, so we actually need to validate the PREVIOUS panel
function validatePanel(panel) {
	var valid = true;

	// Validate the mountingPanel
	if (panel=='uploadPanel') {
		if (selectedMounting=='') {
			$('.mountingPanel .errorMessage').addClass('visible');
			$('.mountingPanel').addClass('error');
			valid = false;
		}
		else {
			$('.mountingPanel .errorMessage').removeClass('visible');
			$('.mountingPanel').removeClass('error');
			valid = true;
		}
	}

	// Validate the uploadPanel
	if (panel=='detailsPanel') {
		$(".uploadPanel input, .uploadPanel textarea, .uploadPanel .selectContainer").each(function() {
			if ($(this).attr('rel')=='mandatory' && $(this).val()=='') {
				$(this).addClass('error');
				valid = false;
			}
			else {
				$(this).removeClass('error');
			}
		});

		$(".uploadPanel .dropzoneContainer").each(function() {
			if ($(this).hasClass('complete')===false) {
				$(this).addClass('basicError');
				valid = false;
			}
			else {
				$(this).removeClass('basicError');
			}
		});

		if ((dropzoneCount-1)<minForms) {
			$('.addNew').addClass('error');
			valid = false;
		}
		else {
			$('.addNew').removeClass('error');
		}

		// validate photo instructions
		for (var i = 1; i <= 4; i++) {
			if (!$("#photoInstructions" + i).is(':checked')) {
				$('#photoInstructionsLabel' + i).addClass('error');
				valid = false;
			} else {
				$('#photoInstructionsLabel' + i).removeClass('error');
			}
		}

		if (valid===false) {
			$('.uploadPanel').addClass('error');
			$('.uploadPanel .errorMessage').addClass('visible');
		}
		else {
			$('.uploadPanel').removeClass('error');
			$('.uploadPanel .errorMessage').removeClass('visible');
		}
	}

	// Validate the detailsPanel
	if (panel=='final') {

		$(".detailsPanel #form1 input, .detailsPanel #form1 textarea").each(function() {
			var validEmail = true;

			if ($(this).attr('name')=='email') {
				var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				if (!re.test($(this).val())) {
					validEmail = false;
				}
				else {
					$.ajax({
						type: "POST",
						async: false,
						url: themePath+"php/validateEmail.php",
						data: "email="+$(this).val(),
						success: function(msg) {
							if (msg!='VALID') {
								validEmail = false;
							}
						}
					});
				}
			}

			if (($(this).attr('rel')=='mandatory' && $(this).val()=='' && $(this).parent().css('display')!='none') || validEmail===false) {
				$(this).addClass('error');
				valid = false;
			}
			else {
				$(this).removeClass('error');
			}
		});
		$(".detailsPanel #form1 .selectContainer select").each(function() {
			if ($(this).parent().attr('rel')=='mandatory' && ($(this).val()=='' || $(this).val()==null) && $(this).parent().parent().css('display')!='none') {
				$(this).parent().addClass('error');
				valid = false;
			}
			else {
				$(this).parent().removeClass('error');
			}
		});


		$(".detailsPanel #form2 input, .detailsPanel #form2 textarea, .detailsPanel #form2 .selectContainer").each(function() { $(this).removeClass('error'); });

		$(".detailsPanel #form2 .visible input, .detailsPanel #form2 .visible textarea").each(function() {
			if ($(this).attr('rel')=='mandatory' && $(this).val()=='' && $(this).parent().css('display')!='none') {
				$(this).addClass('error');
				valid = false;
			}
			else {
				$(this).removeClass('error');
			}
		});
		$(".detailsPanel #form2 .visible .selectContainer select").each(function() {
			if ($(this).parent().attr('rel')=='mandatory' && ($(this).val()=='' || $(this).val()==null) && $(this).parent().parent().css('display')!='none') {
				$(this).parent().addClass('error');
				valid = false;
			}
			else {
				$(this).parent().removeClass('error');
			}
		});

		if (!$("#termsAndConditions").is(':checked')) {
			$('#termsLabel').addClass('error');
			valid = false;
		}
		else {
			$('#termsLabel').removeClass('error');
		}


		if (valid===false) {
			$('.detailsPanel').addClass('error');
			$('.detailsPanel .errorMessage').addClass('visible');
		}
		else {
			$('.detailsPanel').removeClass('error');
			$('.detailsPanel .errorMessage').removeClass('visible');

			completeOrder();
			return false;
		}
	}


	if (valid===true) {
		activePanels[panel] = true;
		return true;
	}
	else {
		$('body').animate({ scrollTop: $('body').prop("scrollHeight") - $('body').height() }, 500);
		activePanels[panel] = false;
		return false;
	}
}




/* COMPLETE ORDER
------------------------------------------------------- */
function completeOrder() {
	// Set button state to loading
	$('#finishButton').addClass('loading');
	$('#finishButton a').attr('href', 'javascript:;');


	//console.log('Complete order -');
	var order = {};



	// Get product id
	// ------------------------------------------------------------

	order['id'] = product_id;



	// Get coupon code
	// ------------------------------------------------------------

	order['coupon'] = couponCode;



	// Get mounting details
	// ------------------------------------------------------------

	order['mounting'] = {};
	var tmp = selectedMounting.split('_');
	order['mounting']['type'] = tmp[0];
	order['mounting']['size'] = tmp[1].replace(' x ', 'x');
	//console.log('Mounting type: '+mountingType);
	//console.log('Mounting size: '+mountingSize);



	// Get upload details
	// ------------------------------------------------------------

	// General portrait details
	order['generalPortraitFields'] = {};
	$(".uploadPanel .generalForm input, .uploadPanel .generalForm textarea").each(function() {
		order['generalPortraitFields'][$(this).attr('placeholder')] = $(this).val();
	});
	//console.log('General portrait fields -');
	//console.log(order['generalPortraitFields']);

	// Figure portrait details
	order['figurePortraitDetails'] = {};
	order['uploadedImages'] = {};
	var i = 0;
	$(".uploadPanel .uploadFormContainer .uploadForm").each(function() {
		order['figurePortraitDetails'][i] = {};

		order['uploadedImages'][i] = {};
		order['uploadedImages'][i]['name'] = $(this).find('.dz-details .dz-filename span').html();
		order['uploadedImages'][i]['url'] = sitePath+'wp-content/uploads/portraits/'+$(this).find('.dz-details img').attr('rel');

		var currentFigure = -1;
		var prevField = '';
		$(this).find('textarea, input').each(function() {
			var currentField = $(this).attr('name').replace('field_', '');

			if (parseInt(currentField)<parseInt(prevField) || prevField=='') {
				currentFigure++;
				order['figurePortraitDetails'][i][currentFigure] = {};
			}
			prevField = currentField;

			order['figurePortraitDetails'][i][currentFigure][$(this).attr('placeholder')] = $(this).val();
		});

		i++;
	});
	//console.log('Figure portrait fields -');-
	//console.log(order['figurePortraitDetails']);


	// Get newsletter
	order['newsletterSignup'] = $('#newsletterSignup').is(':checked');



	// Get customer details
	// ------------------------------------------------------------

	order['customerDetails'] = {};

	// Form 1
	order['customerDetails']['billingAddress'] = {};
	$(".detailsPanel #form1 input, .detailsPanel #form1 textarea, .detailsPanel #form1 select").each(function() {
		if (($(this).attr('name')!='stateSelect1' && $(this).attr('name')!='stateInput1') || $(this).val()!='') {
			order['customerDetails']['billingAddress'][$(this).attr('name').replace('1', '').replace('Input', '').replace('Select', '')] = $(this).val();
		}
	});

	order['customerDetails']['shippingAddress'] = {};
	if ($('#shipToDifferentAddress').is(":checked")) {
		$(".detailsPanel #form2 input, .detailsPanel #form2 textarea, .detailsPanel #form2 select").each(function() {
			if (($(this).attr('name')!='stateSelect2' && $(this).attr('name')!='stateInput2') || $(this).val()!='') {
				if ($(this).attr('name')!='address2') {
					order['customerDetails']['shippingAddress'][$(this).attr('name').replace('2', '').replace('Input', '').replace('Select', '')] = $(this).val();
				}
				else {
					order['customerDetails']['shippingAddress'][$(this).attr('name')] = $(this).val();
				}
			}
		});
	}
	else {
		order['customerDetails']['shippingAddress'] = {};
		for (var key in order['customerDetails']['billingAddress']) {
			if (key!='phone' && key!='email') {
				order['customerDetails']['shippingAddress'][key] = order['customerDetails']['billingAddress'][key];
			}
		}
	}
	//console.log('Customer details -');-
	//console.log(customerDetails);




	// Pass to PHP via AJAX
	// -----------------------------------------------------------

	var jsonOrder = JSON.stringify({order: order});

	$.ajax({
		type: "POST",
		url: themePath+"php/processOrder.php",
		contentType: "application/json; charset=utf-8",
		data: jsonOrder,
		success: function(msg) {
			$(window).unbind('beforeunload');

			$('#paypalCustom').val(msg);

			var tmp = msg.split('|-|-|');
			$('#paypalAmount').val(tmp[1]);

			$('#paypalForm').submit();
		}
	});

}






/* NAVIGATION
------------------------------------------------------- */
var activePanels = [];
$(document).ready(function() {
	$("section").each(function() {
		activePanels[$(this).attr('class').split(' ')[0]] = false;
	});
	activePanels['portraitPanel'] = true;

	$('.details a').click(function(e){
		e.preventDefault();
		$('nav .for_mob').toggle();
	});

	// activate variant in mobile select
	$('.selectBoxContainer .option').click(function(){
		var type = $(this).data('type');
		var dimensions = $(this).data('dimensions');
		var $mobileOption = $('.mounting-select-mobile select option').filter(
			function() {
				return $(this).data("type") == type && $(this).data("dimensions") == dimensions
			}
		);
		$mobileOption.prop('selected', true);

		// copy mobile description
		var $wrap = $('.mounting-select-desktop > .' + type);
		$('.mounting-select-mobile .info').html($('h2.title', $wrap).clone());
		$('.mounting-select-mobile .info').append($('div.for_mob .description', $wrap).clone());
	});
});

var currentlyChanging = false;
function changePanel(panel) {
	if (validatePanel(panel)) {
		if (menuShowing===true) {
			hideMenu();
			setTimeout(function() { doPanelChange(panel); }, 400);
		}
		else {
			doPanelChange(panel);
		}
	}
}

var firstChange = true;
function doPanelChange(panel) {
	if (currentlyChanging===false && activePanels[panel]===true) {

		// If this is the first panel change, setup the "Are you sure you want to leave" message
		if (firstChange===true)  {
			firstChange = false;
			// bind only for non-IE browsers (IE <= 10 triggers this event with every occassion)
			if(!msieversion()) {
				$(window).bind('beforeunload', function() {
					return 'If you leave this page you will lose all of the details you have added.';
				});
			}
		}


		currentlyChanging = true;
		setTimeout(function() { currentlyChanging = false; }, 1050);

		// Get the sections
		var sections = [];
		$("section").each(function() {
			sections.push($(this).attr('class').split(' ')[0]);
		});

		// For each section, workout what it is
		var foundCurrentPanel = false;
		var prevPanels = [];
		var nextPanels = [];
		for (var i = 0; i<sections.length; i++) {
			if (sections[i]==panel) {
				foundCurrentPanel = true;
			}
			else if (foundCurrentPanel===false) {
				prevPanels.push(sections[i]);
			}
			else if (foundCurrentPanel===true) {
				nextPanels.push(sections[i]);
			}
		}


		// Action the current panel
		$('.'+panel).css('top', 0);
		$('.currentPanel').removeClass('currentPanel');
		$('.'+panel).addClass('currentPanel');
		$('.'+panel+' .innerPanel').css('height', $('.'+panel).outerHeight()+'px');
		$('.'+panel+' .innerPanel, .'+panel+' .nextButton').css('top', '0');
		setTimeout(function() { $('.'+panel).css('position', 'relative'); $('.'+panel+' .innerPanel').css('height', 'auto'); }, 1050);

		// Action the previous panels
		var z = 1;
		for (var i = (prevPanels.length-1); i>=0; i--) {
			if (z==1) {
				$('.'+prevPanels[i]+' .innerPanel, .'+prevPanels[i]+' .nextButton').css('position', 'relative');
				$('.'+prevPanels[i]+' .innerPanel, .'+prevPanels[i]+' .nextButton').css('top', '-'+$('body').scrollTop()+'px');
			}

			$('.'+prevPanels[i]+' .innerPanel').css('height', $('.'+prevPanels[i]+' .innerPanel').outerHeight()+'px');
			setTimeout(function() { $('.'+prevPanels[i]+' .innerPanel').css('height', 'auto'); }, 1050);

			$('.'+prevPanels[i]).css('position', 'absolute');
			$('.'+prevPanels[i]).css('top', '-100%');
			z++;
		}

		// Action the next panels
		var z = 1;
		for (var i = 0; i<nextPanels.length; i++) {
			$('.'+nextPanels[i]+' .innerPanel').css('height', $('.'+nextPanels[i]+' .innerPanel').outerHeight()+'px');
			setTimeout(function() { $('.'+nextPanels[i]+' .innerPanel').css('height', 'auto'); }, 1050);

			$('.'+nextPanels[i]).css('position', 'absolute');
			$('.'+nextPanels[i]).css('top', (100*z)+'%');
			z++;
		}


		navColorInterval = setInterval(function() { setNavColor(panel); }, 10);


		// STEP NAV
		// Make current one regular
		$('nav .current').removeClass('current');

		// Change new one to current
		var stepID = panel.replace('Panel', 'Step');
		var currentHTML = $('#'+stepID+' div').html();
		if (typeof currentHTML == 'undefined') {
			currentHTML = $('#'+stepID+' a').html();
		}
		$('#'+stepID).html("<a href=\"javascript: changePanel('"+panel+"');\" class='current'>"+currentHTML+"</a>");

	}
}


var navColorInterval = '';
function setNavColor(panel) {
	var topPos = $('.portraitPanel').offset().top;
	var windowHeight = $(window).height();

	// If we're sliding to portraitPanel, we need to try and ADD the color
	if (panel=='portraitPanel') {
		if (topPos+windowHeight>0) {
			$('nav').addClass(navColor);
			$('nav').addClass('color');
			clearInterval(navColorInterval);
		}
	}
	// Otherwise, we need to REMOVE the color
	else {
		if (topPos+windowHeight - $('nav').height()<0) {
			$('nav').removeClass(navColor);
			$('nav').removeClass('color');
			clearInterval(navColorInterval);
		}
	}
}




// Mozilla Firefox fix
function sizePanels() {
	$("section").each(function() {
		$(this).css('height', $(window).height()+'px');
	});
}


var FIREFOX = /Firefox/i.test(navigator.userAgent);

if (FIREFOX) {
	$(window).resize(function() {
		sizePanels();
	});
	$(document).ready(function() {
		sizePanels();
	});
}




/* CUSTOM SELECT BOXES
------------------------------------------------------- */
function addSelectActions() {
	$(".selectBox").each(function() {
		$(this).attr('onfocus', "showOptions('"+$(this).attr('id')+"');");
		$(this).attr('onblur', "hideOptions('"+$(this).attr('id')+"');");

		$(this).attr('rel', $(this).children(".selectedOption").html());
	});

	$(".selectBox .option").each(function() {
		$(this).attr('onclick', "selectOption('"+$(this).parent().attr('id')+"', '"+$(this).html()+"', '"+$(this).attr('rel')+"', '"+$(this).attr('name')+"');");
		$(this).attr('ontouchend', "selectOption('"+$(this).parent().attr('id')+"', '"+$(this).html()+"', '"+$(this).attr('rel')+"', '"+$(this).attr('name')+"');");
	});
}

function showOptions(id) {
	$('#'+id).parent().css('z-index', '2');
	$('#'+id).addClass('openDown');

	// Is it visible when it pops down? If not, pop up instead
	if ($('#'+id).visible()===false) {
		$('#'+id).removeClass('openDown');
		$('#'+id).addClass('openUp');

		// Reverse child DOM elements
		var list = $('#'+id);
		var listItems = list.children('div');
		list.append(listItems.get().reverse());

		// Reposition element
		$('#'+id).css('margin-top', '-'+($('#'+id).outerHeight()-($('#'+id+' .selectedOption').outerHeight()+4))+'px');
	}

	if (!("ontouchstart" in document.documentElement)) {
		setTimeout(function() { $('#'+id).attr('onclick', "$(this).blur();"); }, 200);
	}
	else {
		setTimeout(function() { $('#'+id).attr('ontouchend', "$(this).blur();"); }, 200);
	}
}


function hideOptions(id) {
	$('#'+id).parent().css('z-index', 'auto');
	$('#'+id).removeClass('openDown');

	if ($('#'+id).hasClass('openUp')) {
		$('#'+id).removeClass('openUp');

		// Reverse child DOM elements
		var list = $('#'+id);
		var listItems = list.children('div');
		list.append(listItems.get().reverse());

		// Reposition element
		$('#'+id).css('margin-top', '0');
	}

	$('#'+id).removeClass('openDown');


	if (!("ontouchstart" in document.documentElement)) {
		$('#'+id).attr('onclick', "showOptions('"+$('#'+id).attr('id')+"');");
	}
	else {
		$('#'+id).attr('ontouchend', "showOptions('"+$('#'+id).attr('id')+"');");
	}
}

var selectedMounting = '';
var mountingPrice = 0;
var mountingPostage = 0;
function selectOption(selectBoxId, value, localPrice, postage) {
	mountingPostage = postage;
	calculatePostage();

	$(".selected").each(function() {
		if ($(this).children(".selectBox").attr('id') != selectBoxId) {
			$(this).removeClass('selected');
			$(this).children(".selectBoxContainer").children(".selectBox").children(".selectedOption").html($(this).children(".selectBoxContainer").children(".selectBox").attr('rel'));
		}
	});


	var tmp = selectBoxId.replace('Select', '');
	selectedMounting = tmp+'_'+value;

	$('#'+selectBoxId).parent().parent().addClass('selected');
	$('#'+selectBoxId+' .selectedOption').html(value);

	// Update the checkout nav
	var type = selectBoxId.replace('Select', '');
	type = type.charAt(0).toUpperCase() + type.slice(1);
	$('.checkoutNav .mounting').removeClass('disabled');
	$('.checkoutNav .mounting .text').html(type+' ('+value+')');
	$('.checkoutNav .mounting .price').html('$'+(parseFloat(localPrice)+parseFloat(price)));
	mountingPrice = localPrice;
	updateTotalPrice();

	// Chrome bug fix - border on coupon code goes all weird?
	var couponCodeValue = $('.couponCode input').val();
	$('.couponCode').html($('.couponCode').html());
	$('.couponCode input').val(couponCodeValue);


	// Update the preview (10mm = 1px)
	var tmp = value.split(' x ');
	var width = tmp[0].replace('mm', '');
	var height = tmp[1].replace('mm', '');

	$('.preview .box').css('width', (width/10)+'px');
	$('.preview .box').css('height', (height/10)+'px');
	$('.preview .box').css('margin-left', '-'+(((width/10)/2)+29)+'px');

	$('.preview .box').addClass('visible');

	validatePanel('uploadPanel');
}

$(document).ready(function() {
	addSelectActions();
});





/* UPLOAD BOXES
------------------------------------------------------- */
function addUploadBox(targetDiv) {
	var maxSize = 20;
	var uniqueTime = Date.now();
	$(targetDiv).dropzone({
		url: themePath+"php/upload.php?unique="+uniqueTime,
		addRemoveLinks: true,
		maxFilesize: maxSize, // MB
		clickable: true,
		maxFiles: 1,
		thumbnailWidth: null,
		thumbnailHeight: 124,
		acceptedFiles: 'image/*',

		init: function() {
			this.on("addedfile", function() {
				$(targetDiv).removeClass('complete');
				$(targetDiv).removeClass('error');
				$(targetDiv).addClass('uploading');

				if (this.files[1] != null) {
					this.removeFile(this.files[0]);
				}
			});

			this.on("complete", function() {
				if (this.files.length > 0 && (this.files[0].status=='complete' || this.files[0].status=='success')) {
					$(targetDiv).removeClass('uploading');
					$(targetDiv).addClass('complete');

					$(targetDiv+' img').attr('rel', uniqueTime+'-'+this.files[0].name);
				}
			});

			this.on("error", function() {
				if (this.files[0].size > ((maxSize*1000)*1000)) {
					$(targetDiv+' .errorText').html('<br />This file selected is too large.');
				}
				else {
					$(targetDiv+' .errorText').html('This file selected is not an image.');
				}

				if (this.files[0].status=='error') {
					$(targetDiv).addClass('error');
				}

				this.removeFile(this.files[0]);
			});

			// When a file is removed, this is called - using delete.php, we can delete the stuff
			this.on("removedfile", function(file) {
				if (this.files.length == 0) {
					$(targetDiv).removeClass('uploading');
					$(targetDiv).removeClass('complete');
				}

				$.ajax({
					url: themePath+"php/delete.php?unique="+uniqueTime,
					type: "POST",
					data: { 'name': file.name}
				});
			});
		}
	});
}


var dropzoneCount = 1;
var uniqueDropzoneID = 0;
function addUploadForm() {

	var deleteButtonHTML = "<a href=\"javascript: var a = confirm('Are you sure you want to remove this image?'); if (a) { deleteUploadForm('.dropzoneContainer"+uniqueDropzoneID+"'); }\" class='deleteForm'><img src='"+themePath+"images/smallCrossIcon.png' alt='Remove' /></a>";

	var peopleOptions = '';
	var tmpMaxForms = maxForms;

	if (tmpMaxForms==0 || tmpMaxForms=='') {
		tmpMaxForms = 20;
	}
	else {
		tmpMaxForms -= (dropzoneCount-1);
	}
	for (i=0; i<tmpMaxForms; i++) {
		if (i==0) {
			var people = 'Person';
		}
		else {
			var people = 'People';
		}
		peopleOptions += "<option value='"+(i+1)+"'>"+(i+1)+" "+people+"</option>";
	}

	var howManyPeopleHTML = "<div class='howManyPeople'>How many people in this photo are being used in this design?<br /><span class='small'>If more than one, they will be used from left to right.</span> <div class='selectContainer' rel='mandatory'><select onchange=\"$(this).css('color', '#436178'); showFormHTML('dropzoneContainer"+uniqueDropzoneID+"', $(this).val(), false); updateTotalPrice();\"><option value='' default selected disabled>Please select</option>"+peopleOptions+"</select></div></div>";
	var formHTML = "<div class='uploadForm' rel='1'><div class='dropzoneContainer dropzoneContainer"+uniqueDropzoneID+"'><div class='regularContent'><img src='"+themePath+"images/uploadImageIcon.png' alt='' /><div class='clear'></div>Drop an image here<br /><span class='small'>or</span><br />Click to upload<div class='maxSize'>Max file fize: 20mb</div></div> <!-- .regularContent --><div class='errorContent'><div class='errorText'></div><div class='errorButton' onclick=\"$(this).parent().parent().click();\">Click here to try again</div><div class='maxSize'>Max file fize: 20mb</div></div> <!-- .errorContent --></div> <!-- .dropzoneContainer1 --><div class='form'>"+howManyPeopleHTML+"</div> <!-- .form -->"+deleteButtonHTML+"<div class='clear'></div></div> <!-- .uploadForm -->";

	$('.uploadFormContainer').append(formHTML);
	addUploadBox('.dropzoneContainer'+uniqueDropzoneID);

	dropzoneCount++;
	uniqueDropzoneID++;

	hideShowAddButton();

	// if only one person, preactivate
	if (tmpMaxForms==1) {
		showFormHTML( ('dropzoneContainer'+(uniqueDropzoneID-1) ) , '1', true);
		updateTotalPrice();
	}

}


function showFormHTML(dropzoneContainer, people, noTransition) {

	if (noTransition===true) {
		transitionSpeed = 0;
	}
	else {
		transitionSpeed = 200;
	}

	var formHTMLOutput = '';

	// attach chosen number of persons
	if(maxForms > 1) {
		formHTMLOutput += "<div class='howManyPeopleText'>" + people + ( people > 1 ? ' people' : ' person') + " in this image</div>";
	}

	for (i=0; i<people; i++) {
		if (figureFormHTML!='') {
			formHTMLOutput += "<div class='personHeader'>Person "+(i+1)+" <span>(From left)</span></div>"+figureFormHTML;
		}
	}
	dropzoneCount+=(people-1);

	$('.'+dropzoneContainer).parent().find('.form .howManyPeople').fadeOut(transitionSpeed, function() {
		$('.'+dropzoneContainer).parent().find('.form').fadeOut((transitionSpeed/2), function() {
			$('.'+dropzoneContainer).parent().find('.form').html(formHTMLOutput);
			$('.'+dropzoneContainer).parent().find('.form').fadeIn(transitionSpeed);
			hideShowAddButton();
		});
	});

	$('.'+dropzoneContainer).parent().attr('rel', people);

	// Update the checkout nav
	if ((dropzoneCount-1)>0) {
		$('.checkoutNav .figures').removeClass('disabled');
		if ((dropzoneCount-1)<=1) {
			var people = ' Person';
		}
		else {
			var people = ' People';
		}
		$('.checkoutNav .figures .text').html((dropzoneCount-1)+people);
		var tmpFigurePrice = '$'+(((dropzoneCount-1)*price_per_figure).toFixed(2));
		if (tmpFigurePrice=='$0.00') {
			tmpFigurePrice = 'Free!';
		}
		$('.checkoutNav .figures .price').html(tmpFigurePrice);
	}
	else {
		$('.checkoutNav .figures').addClass('disabled');
		$('.checkoutNav .figures .text').html('');
		$('.checkoutNav .figures .price').html('');
	}
}


function deleteUploadForm(obj) {
	// If there is an image, delete it from the server
	if ($(obj+' img').attr('rel')) {
		var fileName = $(obj+' img').attr('rel');
		var unique = fileName.split('-')[0];
		var name = fileName.replace(unique+'-', '');

		$.ajax({
			url: themePath+"php/delete.php?unique="+unique,
			type: "POST",
			data: { 'name': name}
		});
	}

	// Then remove the container
	for (i=0; i<$(obj).parent().attr('rel'); i++) {
		dropzoneCount--;
	}
	$(obj).parent().remove();


	// If there's a "How many people" question present, recalculate the options for this dropdown
	if ($('.howManyPeople').length > 0) {
		var peopleOptions = '';
		var tmpMaxForms = maxForms;

		if (tmpMaxForms==0 || tmpMaxForms=='') {
			tmpMaxForms = 20;
		}
		else {
			tmpMaxForms -= (dropzoneCount-2);
		}
		for (i=0; i<tmpMaxForms; i++) {
			if (i==0) {
				var people = 'Person';
			}
			else {
				var people = 'People';
			}
			peopleOptions += "<option value='"+(i+1)+"'>"+(i+1)+" "+people+"</option>";
		}

		$('.howManyPeople select').html("<option value='' default selected disabled>Please select</option>"+peopleOptions);
	}


	if ((dropzoneCount-1)>0) {
		$('.checkoutNav .figures').removeClass('disabled');
		if ((dropzoneCount-1)<=1) {
			var people = ' Person';
		}
		else {
			var people = ' People';
		}
		$('.checkoutNav .figures .text').html((dropzoneCount-1)+people);
		$('.checkoutNav .figures .price').html('$'+(((dropzoneCount-1)*price_per_figure).toFixed(2)));
	}
	else {
		$('.checkoutNav .figures').addClass('disabled');
		$('.checkoutNav .figures .text').html('');
		$('.checkoutNav .figures .price').html('');
	}

	updateTotalPrice();
	hideShowAddButton();
}

function hideShowAddButton() {
	if ((dropzoneCount>maxForms && maxForms!=0) || $('.howManyPeople').length > 0) {
		$('.addNew').css('display', 'none');
	}
	else {
		$('.addNew').fadeIn(400);
	}
}


var totalPrice = 0;
function updateTotalPrice() {
	totalPrice = (parseFloat(price)+parseFloat(mountingPrice)+parseFloat(((dropzoneCount-1)*price_per_figure))).toFixed(2);

	if (discountFlat>0) {
		totalPrice = (totalPrice-discountFlat).toFixed(2);
		if(totalPrice < 0) totalPrice = 0;
	}
	else if (discountPercentage>0) {
		totalPrice = (totalPrice-((totalPrice/100)*discountPercentage)).toFixed(2);
	}

	totalPrice = (parseFloat(totalPrice)+parseFloat(postageCost)).toFixed(2);

	var priceArr = totalPrice.split('.');

	$('.subTotal .value').html('$'+priceArr[0]+'<span>.'+priceArr[1]+'</span>');
}

var rightNow = new Date();
var today = rightNow.toISOString().slice(0,10).replace(/-/g, '');
var discountFlat = 0;
var discountPercentage = 0;
var freeShipping = false;
var couponCode = '';
// validate by ajax
function validateCouponCode(code) {
	if (code!='') {
		// ajax function to check code and process price changes
		doValidCheck(code);

	} else {
		// code empty, erase values
		$('.couponCode').removeClass('valid');
		$('.couponCode').removeClass('invalid');
		discountPercentage = 0;
		discountFlat = 0;
		freeShipping = false;
		couponCode = '';

		// recount
		calculatePostage();
		updateTotalPrice();
	}
}


function doValidCheck(code) {
	// check code by ajax
	$.ajax({
		url: ajax_url,
		data: {
			action: 'validate_coupon',
			code: code
		},
		method: 'POST',
		success: function(raw_data) {
			var data = $.parseJSON(raw_data);

			// function handling the result
			var processReturnedData = function(data) {
				// default status
				var status = false;

				// coupon returned correctly
				if (data.status === true) {
					// default status validated, now need to pass the rules
					status = true

					// push data to object as previously used so old code can be kept
					var code = data.coupon;
					// If NOT in included categories = fail
					if (code.product_categories.length > 0) {
						inc_cats = code.product_categories;

						var included = false;
						for (i=0; i<inc_cats.length; i++) {
							if ($.inArray(inc_cats[i], product_cats)!==-1) {
								included = true;
							}
						}
						if(included === false) status = false;
					}

					// If IN excluded products = fail
					if (code.exclude_product_categories.length > 0) {
						ex_cats = code.exclude_product_categories;

						for (i=0; i<ex_cats.length; i++) {
							if ($.inArray(ex_cats[i], product_cats)!==-1) {
								status = false;
							}
						}
					}

					// Usage limit
					if (code.usage_count >= code.usage_limit && code.usage_limit>0 && code.usage_limit!='') { status = false; } // Usage Limit
					else if(code.expiry_date<(Date.now()/1000) && code.expiry_date!='') { status = false; } 	// Exp date
					else if(code.product_ids!='' && code.product_ids.indexOf(product_id.toString())==-1) { status = false; } // If NOT in included products = fail
					else if(code.exclude_product_ids!='' && code.exclude_product_ids.indexOf(product_id.toString())!=-1) { status = false; }// If IN excluded products = fail

					if (status === true) {
						// coupon is valid
						$('.couponCode').removeClass('invalid');
						$('.couponCode').addClass('valid');

						if (code.coupon_amount!='' && code.coupon_amount!=0) {
							if (code.discount_type=='percent_product') {
								var couponText = code.coupon_amount+'% off this purchase!<br />';
								discountPercentage = code.coupon_amount;
							}
							else {
								var couponText = '$'+code.coupon_amount+' off this purchase!<br />';
								discountFlat = code.coupon_amount;
							}
						}
						else {
							var couponText = '';
						}

						if (code.free_shipping=='yes') {
							var shippingText = 'Free shipping!';
							freeShipping = true;
						}
						else {
							var shippingText = '';
							freeShipping = false;
						}

						$('.couponText').html(couponText+shippingText);
						return true;
					}
				}

				// show error if status invalid
				if (status === false) {
					$('.couponCode').removeClass('valid');
					$('.couponCode').addClass('invalid');
					$('.couponText').html('Invalid coupon code!');
					return false;
				}

			}

			// call result processing
			var res = processReturnedData(data);
			if (res) {
				// discount type set by processReturnedData() function, only set couponCode
				couponCode = code;

			} else {
				// no discount
				discountPercentage = 0;
				discountFlat = 0;
				freeShipping = false;
				couponCode = '';
			}

			// recount
			calculatePostage();
			updateTotalPrice();
		}
	});

}


function showStates(countryBox) {
	var country = $("#"+countryBox).val();

	if (countryBox=='country1') {
		var num = 1;
	}
	else {
		var num = 2;
	}

	if (states[country]) {
		var options = '';
		for(key in states[country]) {
			options += "<option value='"+key+"'>"+states[country][key]+"</option>";
		}

		$("#stateSelect"+num+" select").html("<option value='' default selected disabled>State / County</option>"+options);

		$("#stateInput"+num).css('display', 'none');
		$("#stateSelect"+num).css('display', 'inline-block');
	}
	else {
		$("#stateSelect"+num).css('display', 'none');
		$("#stateInput"+num).css('display', 'inline-block');
	}

	calculatePostage();
}

var postageCost = 0;
function calculatePostage() {

	if (shipToDifferentAddress.checked===true) {
		var country = $('#country2').val();
	}
	else {
		var country = $('#country1').val();
	}

	if (!country && freeShipping===false) {
		$('.checkoutNav .postage').addClass('disabled');
		$('.checkoutNav .postage .text').html('');
		$('.checkoutNav .postage .price').html('');
		postageCost = 0;
	}
	else {
		if (freeShipping===false) {
			if (country=='AU') {
				postage = local_delivery;
			}
			else {
				postage = international_delivery;
			}

			postage = (parseFloat(postage)+parseFloat(mountingPostage)).toFixed(2);
			postageCost = postage;
		}
		else {
			postage = 0;
			postageCost = 0;
		}

		if (postage==0) {
			postage = 'Free!';
		}
		else {
			postage = '$'+postage;
		}

		$('.checkoutNav .postage').removeClass('disabled');
		$('.checkoutNav .postage .text').html('Postage');
		$('.checkoutNav .postage .price').html(postage);
	}

	updateTotalPrice();
}

// bind IE fix for dropzone that is not activated when clicked the content in the middle
if(msieversion() && msieversion() < 11) {
	$(function() {
		$('body').on('click', '.dropzoneContainer > .regularContent', function() {
			$(this).parent('.dropzoneContainer').trigger('click');
		});
	});
}
