function changeLogoColor(data) {
	if (data===false) {
		var deg = $('.ls-slide').first().attr('id');
	}
	else {
		var deg = $('.ls-slide:eq('+(data['nextLayerIndex']-1)+')').attr('id')
	}

	$('.bannerLogo, .browseButton, .topBrowseButton').css('-webkit-filter', 'hue-rotate('+deg+'deg)');
}



/* MASONRY
------------------------------------------------------- */
function changeNav(obj, type, doScroll) {

	$('.filterNav .current').removeClass('current');
	$(obj).addClass('current');

	$('.designsContent > .item').each(function () {
		if ($(this).attr('rel').indexOf(type)==-1 && type!='all') {
			$(this).removeClass('visible');
		}
		else {
			$(this).addClass('visible');
		}
	});

	if (pageLoaded===true) {
		$('.designsContent').masonry('reload');
	}

	if (doScroll===true) {
		scrollTo('designsPanel');
	}

	// fix when in initial ten portraits is not the chosen category - in that case portraits list is empty
	// but scrolling loaded more items, so we need to call the function once again to load the newly attached portraits
	// final condition is a check if we still have some unloaded portraits prepared to show
	if($('.designsContent > .item.visible').length === 0 && doScroll  && $('.designsContent > .item').length < galleryItem.length) {
		setTimeout(function() {
			changeNav(obj, type, true);
		}, 1000);
	}
}

var currentBlock = 0;
function addMasonryBlocks(forceAdd) {
	var sections = setupSections();

	// If we're scrolled to near the bottom of the .designsPanel add in more items
	if (($(window).scrollTop() + $(window).height() >= (sections['designsPanel']+$('.designsPanel').outerHeight() - 300) || forceAdd===true) && currentBlock<galleryItem.length) {

		for (i=0; i<10; i++) {
			//$('.designsContent').append("<div class='item' ontouchend=\"if ($(this).hasClass('activeItem')===false) { var origState = false; } else { var origState = true; } $('.activeItem').removeClass('activeItem'); if (origState===false) { $(this).addClass('activeItem'); } else { $(this).removeClass('activeItem'); }\" rel='"+galleryItem[currentBlock]['category']+"' style='width: "+galleryItem[currentBlock]['width']+"px; height: "+galleryItem[currentBlock]['height']+"px;'><div class='overlay'><div class='outerContainer'><div class='innerContainer'><h2 class='title'>"+galleryItem[currentBlock]['title']+"</h2><ul class='description'><li>"+galleryItem[currentBlock]['figures']+"</li></ul> <!-- .description --><a href='portrait/"+galleryItem[currentBlock]['post_name']+"/'>Choose this design</a></div> <!-- .innerContainer --></div> <!-- .outerContainer --></div> <!-- .overlay --><img src='"+galleryItem[currentBlock]['image']+"' alt='' style='width: "+galleryItem[currentBlock]['width']+"px; height: "+galleryItem[currentBlock]['height']+"px;' onload=\"$(this).addClass('showing');\" /></div> <!-- .item -->");
			$('.designsContent').append("<div class='item' rel='"+galleryItem[currentBlock]['category']+"' style='width: "+galleryItem[currentBlock]['width']+"px;'><div class='overlay'><div class='outerContainer'><div class='innerContainer'><h2 class='title'>"+galleryItem[currentBlock]['title']+"</h2><ul class='description'><li>"+galleryItem[currentBlock]['figures']+"</li></ul> <!-- .description --><a href='portrait/"+galleryItem[currentBlock]['post_name']+"/'>Choose this design</a></div> <!-- .innerContainer --></div> <!-- .outerContainer --></div> <!-- .overlay --><img src='"+galleryItem[currentBlock]['image']+"' alt='' style='width: "+galleryItem[currentBlock]['width']+"px; height: "+galleryItem[currentBlock]['height']+"px;' onload=\"$(this).addClass('showing');\" /><div class='description-mobile'><span class='title'>"+galleryItem[currentBlock]['title']+"</span><span class='subtitle'>"+galleryItem[currentBlock]['figures']+"</span></div></div> <!-- .item -->");

			currentBlock++;
			if (currentBlock>=galleryItem.length) {
				$('.loadingMessage').html("<a href=\"javascript: showModal('<div class=\\'textModalInner portraitIdeaModal\\'><h2 class=\\'title\\'>Got a portrait idea?</h2><div style=\\'position: relative;\\'><input type=\\'text\\' placeholder=\\'Name\\' value=\\'\\' name=\\'name\\' rel=\\'mandatory\\' required /><label for=\\'name\\' class=\\'formLabel\\'>Name</label></div><div style=\\'position: relative;\\'><input type=\\'text\\' placeholder=\\'Email\\' value=\\'\\' name=\\'email\\' rel=\\'mandatory\\' required /><label for=\\'email\\' class=\\'formLabel\\'>Email</label></div><div style=\\'position: relative;\\'><textarea placeholder=\\'Your portrait idea\\' rel=\\'mandatory\\' name=\\'portraitIdea\\' required></textarea><label for=\\'portraitIdea\\' class=\\'formLabel\\'>Portrait Idea</label></div><a href=\\'javascript: submitPortraitIdea();\\' class=\\'submitButton\\'>Submit idea</a></div>', 'text');\" class='bigButton'>Got a portrait idea? Let us know.</a>");
				clearInterval(loadingInterval);
				clearInterval(loadMasonryBlocks);
				break;
			}
		}
		if (forceAdd===false) {
			// Reload masonry
			$('.designsContent').masonry('reload');
		}
		// Reapply the filter (but don't scroll back up to the top)
		var clickAction = $('.filterNav .current').data('filter');

		changeNav($('.filterNav .current'), clickAction, false);

		// Bind mobile tap click
		bindPortraitGalleryMobileClick();
	}
}

var pageLoaded = false;
$(document).ready(function() {
	addMasonryBlocks(true);

	// Initialize Masonry
	$('.designsContent').masonry({
		columnWidth: 290,
		gutterWidth: 30,
		itemSelector: '.visible',
		isResizable: false,
		isFitWidth: true
	}).imagesLoaded(function() {
		$(this).masonry('reload');
	});
	pageLoaded = true;
});




/* TRIGGERS
------------------------------------------------------- */
function swapLoadingText() {
	var currentHTML = $('.loadingMessage .text').html();
	if (currentHTML=='Loading') {
		$('.loadingMessage .text').html('Loading.');
	}
	else if (currentHTML=='Loading.') {
		$('.loadingMessage .text').html('Loading..');
	}
	else if (currentHTML=='Loading..') {
		$('.loadingMessage .text').html('Loading...');
	}
	else if (currentHTML=='Loading...') {
		$('.loadingMessage .text').html('Loading');
	}
}


var loadingInterval = '';
var loadMasonryBlocks = '';
$(document).ready(function() {
	$(window).scroll(function() {
		addMasonryBlocks(false);
	});
	$(window).resize(function() {
		$('.designsContent').masonry('reload');
	});
	loadingInterval = setInterval(swapLoadingText, 250);
	loadMasonryBlocks = setInterval(function() { addMasonryBlocks(false) }, 100);

	// touchscreen specific events
	bindPortraitGalleryMobileClick();
});


// detect touchscreen as used in modernizr
function is_touch_device() {
	var bool;
	var ua = navigator.userAgent;
	 if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile/i.test(ua))
	    bool = true;

	 else if (/Chrome/i.test(ua))
	 	// chrome on non-mobile - we show non-touch
	    bool = false;

	 else {
	 	// something different - use modernizr test
	    if (('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch) {
	    	bool = true;
	    } else {
	    	bool = false;
	    }
	 }

	 return bool;
}

function bindPortraitGalleryMobileClick() {
	// no hover for touch devices and old IE
	 if (is_touch_device() || (msieversion() && msieversion() < 11) ) {
		$('body').addClass('touch-support');
		// adjust portraits gallery
		$('.designsPanel .designsContent .item .overlay a').attr('href');
		$('.designsPanel .designsContent .item').on('click', function() {
			window.location.href = $('.overlay a', $(this)).attr('href');
		});
	 } else {
	 	$('body').addClass('touch-not-support');
	 }

}

// dynamic homepage slider blurb
var my_blurb = {

	init: function(el) {
		// show first blurb paragraph
		this.getSlide(1).addClass('visible animate');
	},

	animStop: function(data) {
		// clear classes from the out slided paragraph
		$('.bannerBlurb p.slideOut').removeClass('slideOut visible left right animate');
	},

	// slide to Right - must be defined here to also include automatic sliding
	animStart: function(data) {
		// validate if this callback is not called after user clicked left slide arrow
		if(!$('.bannerBlurb').hasClass('backwards-animate-in-progress')) {
			// slide old text to the left
			$('.bannerBlurb p.visible').addClass('slideOut left');

			// get the new slide paragraph
			var nextOffset = (data.curLayerIndex == data.layersNum ? 1 : data.curLayerIndex + 1 );
			var $newSlide = this.getSlide(nextOffset);

			// place new blurb in position
			$newSlide.addClass('right slideIn').addClass('animate');
			// animate new slide in a bit delayed so present slide has enough time to slide out
			setTimeout(function() {
				$newSlide.removeClass('right slideIn').addClass('visible');
			}, 500);
		}
	},

	// manual slide to previous
	cbPrev: function(data) {
		// define that we are animating to skip animStart handler
		$('.bannerBlurb').addClass('backwards-animate-in-progress');

		// slide old text to right
		$('.bannerBlurb p.visible').addClass('slideOut right');

		// slide-in the new slide
		var nextOffset = (data.curLayerIndex == 1 ? data.layersNum : data.curLayerIndex - 1 );
		var $newSlide = this.getSlide(nextOffset);

		// place new blurb in position
		$newSlide.addClass('left slideIn').addClass('animate');
		// animate new slide in a bit delayed so present slide has enough time to slide out
		setTimeout(function() {
			$newSlide.removeClass('left slideIn').addClass('visible');

			// clear in-progress class
			$('.bannerBlurb').removeClass('backwards-animate-in-progress');
		}, 500);

	},

	getSlide: function(index) {
		return $('.bannerBlurb p:eq(' + ( index - 1 ) + ')');
	}


};