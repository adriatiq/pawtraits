<?php
// SETUP GOOGLE URL SHORTERNER
	// -------------------------------------------------------

	/**
	* Google URL shorten API
	* @version API V1
	*/
	class GoogleURL
	{
	 /**
	  * API URL
	  * @var string
	  */
	 private $apiURL = 'https://www.googleapis.com/urlshortener/v1/url';

	 /**
	  * Google URL shorten Constructor
	  * @param string $apiKey
	  * @return void
	  */
	 function __construct($apiKey)
	 {
	  # API URL with API keys
	  $this->apiURL = $this->apiURL . '?key=' . $apiKey;
	 }

	 /**
	  * Short Long URL
	  * @param string $url as long URL
	  * @return string as short URL or void
	  */
	 public function encode($url)
	 {
	  $data = $this->cURL($url, true);
	  return isset($data->id) ? $data->id : '' ;
	 }

	 /**
	  * Extend Short URL
	  * @param string $url as short URL
	  * @return string as as long URL or void
	  */
	 public function decode($url)
	 {
	  $data = $this->cURL($url, false);
	  return isset($data->longUrl) ? $data->longUrl : '' ;
	 }

	 /**
	  * Send cURL Request
	  * @param string $url
	  * @param bool $post
	  * @return object
	  */
	 private function cURL($url, $post = true)
	 {
	  # create cURL
	  $ch = curl_init();
	  # POST request for URL shorten
	  if ($post) {
	   curl_setopt( $ch, CURLOPT_URL, $this->apiURL );
	   # set header content type for json
	   curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json') );
	   # set request method post
	   curl_setopt( $ch, CURLOPT_POST, true );
	   # send json encoded request
	   curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode(array('longUrl' => $url)) );
	  }
	  # GET request for URL extend
	  else {
	   curl_setopt( $ch, CURLOPT_URL, $this->apiURL . '&shortUrl=' . $url );
	  }
	  curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	  #curl_setopt( $ch, CURLOPT_BINARYTRANSFER, true );
	  curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
	  # execute curl request
	  $json = curl_exec($ch);
	  # close cURL connection
	  curl_close($ch);
	  # return response as object
	  return (object) json_decode($json);
	 }
	}



	// Create instance with key
	$key = 'AIzaSyCG6BwqNflhF4eHQifZnv-06-NaIdON3Ys';
	$api = new GoogleURL($key);



	// ------------------------------------------------------------------------



	// Header
	include 'includes/headStyles.php';


	// Get order ID
	$tmp = explode('/', $_SERVER['REQUEST_URI']);
	array_pop($tmp);
	$orderID = end($tmp);

	// some validation
	if(!isset($orderID) || !is_numeric($orderID)) die('invalid id');

	// get portrait detail img
	$order = new WC_Order( $orderID );
	$items = $order->get_items();
	$product = array_shift($items);


	// Ensure it's a valid order ID
	$sql = "
		SELECT `post_content`
		FROM  `wp_posts`
		WHERE `post_type` =  'shop_order'
		AND `post_status` IN ('wc-completed', 'wc-processing')
		AND `ID` = '".mysql_real_escape_string($orderID)."'
	";
	$result = mysql_query($sql);

	if (mysql_num_rows($result)==0) {
		echo "
			<script type='text/javascript'>
				window.location = '".get_site_url()."';
			</script>
		";
	}
	// If it's valid, let the page load
	else {
		$couponCode = mysql_result($result, 0, 'post_content');

		if ($couponCode=='') {
			$couponCode = time();
		}

		// Generate the key
		$key = md5('akz78'.$couponCode.$orderID.'pq98bv');
?>
		<script type='text/javascript' src='<?php echo $themePath; ?>js/share.js'></script>
	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper regularPage'>




			<?php
				include 'includes/topMenu.php';
				include 'includes/pageNav.php';
			?>




			<!---------- CONTENT PANEL ---------->

			<section class='contentPanel' rel='addNavPadding'>

				<?php
					// Start the wordpress loop
					if (have_posts()) : while (have_posts()) : the_post();

						// Print out the title
						echo "<h1>".trim(wp_title('', false))."</h1>";

						// Print out the content
						the_content();

					endwhile; endif;


					// Get the completed image
					$completedImageFullURL = getOrderCompletedImageUrl($orderID);
					if ($completedImageFullURL) {
						// share URL with image thumbnail
						$shareUrl = getOrderCompletedShareUrl($orderID);

					} else {
						// share homepage
						$shareUrl = site_url();
					}



					// Setup twitter text
					$urlText = urlencode("I just ordered my Epic Portrait! Get your own for 10% off using coupon: ".$couponCode." - ");
				?>


				<div class='facebookContainer'><a href="javascript: shareOnFacebook('<?php echo $orderID; ?>', '<?php echo $key; ?>', '<?php echo $couponCode; ?>', 'Epic Portraits - Proof that you\'re awesome', 'My personal Epic Portrait has just been shipped! You can get one, too. Better yet, if you use this coupon code within the next month, you can get 10% off! Coupon code: <?php echo urlencode($couponCode); ?>', '<?php echo $completedImageFullURL; ?>', '<?php echo $shareUrl; ?>', 'Get 10% off with this coupon code: <?php echo $couponCode; ?>');" class='bigButton facebookButton'><img src='<?php echo $themePath; ?>images/facebookIcon.png' alt='Facebook' /><span>Share on Facebook</span></a></div>
				<div class='twitterContainer'><a href="http://twitter.com/intent/tweet/?text=<?php echo $urlText; ?>&amp;url=<?php echo urlencode($shareUrl)?>" class='bigButton twitterButton' target='_blank'><img src='<?php echo $themePath; ?>images/twitterIcon.png' alt='Twitter' /><span>Share on Twitter</span></a></div>


				<script type='text/javascript'>
					// Do required twitter stuff to the button
					window.twttr = (function(d, s, id) {
					  var js, fjs = d.getElementsByTagName(s)[0],
					    t = window.twttr || {};
					  if (d.getElementById(id)) return;
					  js = d.createElement(s);
					  js.id = id;
					  js.src = "https://platform.twitter.com/widgets.js";
					  fjs.parentNode.insertBefore(js, fjs);

					  t._e = [];
					  t.ready = function(f) {
					    t._e.push(f);
					  };

					  return t;
					}(document, "script", "twitter-wjs"));


					var global_orderID = '<?php echo $orderID; ?>';
					var global_key = '<?php echo $key; ?>';
					var global_couponCode = '<?php echo $couponCode; ?>';

					twttr.ready(function (twttr) {
					  // Now bind our custom intent events
					  twttr.events.bind('tweet', twitterSuccess);
					});
				</script>

				<p class="clear"></p>
				<?php include 'includes/copyright.php'; ?>

			</section> <!-- .contentPanel -->


			<!-- Preload Images -->
			<img src="<?php echo $themePath; ?>images/facebookLoading.gif" alt="" style='position: absolute; visibility: hidden; top: 0; left: 0;' />
			<img src="<?php echo $themePath; ?>images/twitterLoading.gif" alt="" style='position: absolute; visibility: hidden; top: 0; left: 0;' />

		</div> <!-- .contentWrapper -->


		<?php // if user came from email and needs to share, activate
		if(isset($_GET['share']) && $_GET['share'] && in_array($_GET['share'], array('fb', 'tw')) ) {
			$buttonClasses = array(
				'fb' => 'facebookButton',
				'tw' => 'twitterButton',
			);
			?>
			<script type="text/javascript">
				$(function() {
					setTimeout(function() {
						$('a.<?php echo $buttonClasses[$_GET['share']]; ?>')[0].click();
					}, 1000);
				});
			</script>



		<?php } ?>


		<?php
			// Footer
			include 'includes/footer.php';
		?>

	</body>
</html>

<?php
	}
?>