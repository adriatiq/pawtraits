<?php
	// Header
	include 'includes/headStyles.php';
?>
		<link rel="stylesheet" href="<?php echo $themePath; ?>css/tips-tricks.css">

		<script type='text/javascript' src='<?php echo $themePath; ?>js/lib/jquery.lazyload.min.js'></script>
		<script type='text/javascript' src='<?php echo $themePath; ?>js/tips-tricks.js'></script>
	</head>

	<body>
		<?php
			include 'includes/modal.php';
			include 'includes/sideMenu.php';
		?>




		<!---------- MAIN CONTENT ---------->

		<div class='contentWrapper regularPage'>




			<?php
				include 'includes/topMenu.php';
				include 'includes/pageNav.php';
			?>




			<!---------- CONTENT PANEL ---------->

			<section class='contentPanel' rel='addNavPadding'>

				<?php
					// Start the wordpress loop
					if (have_posts()) : while (have_posts()) : the_post();

						// Print out the title
						echo "<h1>".trim(wp_title('', false))."</h1>";

						// Print out the content (if there is any)
						the_content();

						// Output the custom fields
						$i = 0;
						if( have_rows('tip_trick') ):
								while ( have_rows('tip_trick') ) : the_row();
									if ($i==0) {
										echo "<div class='tipTrickContainer' id='inViewStart'>";
									}
									else {
										echo "<div class='tipTrickContainer'>";
									}


										if ($i%2==0) {
											echo "<div class='tipTrickImages'>";
												echo "<div class='incorrectImage'><img src='".$themePath."images/incorrect.png' alt='Incorrect' class='icon' />";
												$image = get_sub_field('tip_incorrect_image');
												$image = $image['url'];
												if ($image!='') {
													echo '<img data-original="'.$image.'" alt="" class="lazy" />';
												}
												echo "</div>";

												echo "<div class='correctImage'><img src='".$themePath."images/correct.png' alt='Correct' class='icon' />";
												$image = get_sub_field('tip_correct_image');
												$image = $image['url'];
												if ($image!='') {
													echo '<img data-original="'.$image.'" alt="" class="lazy" />';
												}
												echo "</div>";
											echo "</div> <!-- .tipTrickImages -->";

											echo "<div class='tipTrickText'>";
												echo "<h2>"; the_sub_field('tip_title'); echo "</h2>";
												echo "<div class='description'>"; the_sub_field('tip_description'); echo "</div>";
											echo "</div> <!-- .tipTrickText -->";
										}
										else {
											echo "<div class='tipTrickText'>";
												echo "<h2>"; the_sub_field('tip_title'); echo "</h2>";
												echo "<div class='description'>"; the_sub_field('tip_description'); echo "</div>";
											echo "</div> <!-- .tipTrickText -->";

											echo "<div class='tipTrickImages'>";
												echo "<div class='incorrectImage'><img src='".$themePath."images/incorrect.png' alt='Incorrect' class='icon' />";
												$image = get_sub_field('tip_incorrect_image');
												$image = $image['url'];
												if ($image!='') {
													echo '<img data-original="'.$image.'" alt="" class="lazy" />';
												}
												echo "</div>";

												echo "<div class='correctImage'><img src='".$themePath."images/correct.png' alt='Correct' class='icon' />";
												$image = get_sub_field('tip_correct_image');
												$image = $image['url'];
												if ($image!='') {
													echo '<img data-original="'.$image.'" alt="" class="lazy" />';
												}
												echo "</div>";
											echo "</div> <!-- .tipTrickImages -->";
										}


									echo "</div> <!-- .tipTrickContainer -->";

									$i++;
								endwhile;
						endif;


					endwhile; endif;
				?>

				<?php include 'includes/copyright.php'; ?>

			</section> <!-- .contentPanel -->



		</div> <!-- .contentWrapper -->





		<?php
			// Footer
			include 'includes/footer.php';
		?>

	</body>
</html>